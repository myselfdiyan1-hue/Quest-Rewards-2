package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.device.InstallationDetectionRepository
import com.example.data.device.UsageTrackingRepository
import com.example.data.local.OfferSessionEntity
import com.example.data.local.UserBalanceEntity
import com.example.data.remote.AppConfig
import com.example.data.remote.FirebaseManager
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SuperOfferViewModel(
    private val rewardRepository: RewardRepository,
    private val firebaseManager: FirebaseManager,
    private val installationRepository: InstallationDetectionRepository,
    private val usageTrackingRepository: UsageTrackingRepository,
    private val isLocalMode: Boolean = false
) : ViewModel() {

    val balance: StateFlow<UserBalanceEntity> = rewardRepository.balance
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = UserBalanceEntity()
        )

    val appConfig: StateFlow<AppConfig> =
        (if (isLocalMode) kotlinx.coroutines.flow.flowOf(AppConfig()) else firebaseManager.observeAppConfig())
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = AppConfig()
            )

    val offerSessions: StateFlow<List<OfferSessionEntity>> = rewardRepository.offerSessions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val activeOfferSession: StateFlow<OfferSessionEntity?> = rewardRepository.activeOfferSession
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = null
        )

    val completedOfferCount: StateFlow<Int> = rewardRepository.completedOfferCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = 0
        )

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    // Fallback (no Usage Access permission): count only the time the user spends AWAY from this
    // screen after the offer app is installed (i.e. while they are in the offer app).
    private val awayStartMsBySession = mutableMapOf<Long, Long>()

    fun mayNeedRestrictedSettingsUnlock(): Boolean = usageTrackingRepository.mayNeedRestrictedSettingsUnlock()

    private fun latestSession(fallback: OfferSessionEntity): OfferSessionEntity =
        activeOfferSession.value?.takeIf { it.id == fallback.id } ?: fallback

    fun onScreenStopped(session: OfferSessionEntity) {
        val current = latestSession(session)
        if (current.targetPackage != null && current.observedUsageSeconds < current.requiredUsageSeconds) {
            awayStartMsBySession[current.id] = System.currentTimeMillis()
        }
    }

    fun onScreenResumed(session: OfferSessionEntity) {
        val current = latestSession(session)
        if (current.targetPackage == null) return
        if (usageTrackingRepository.hasUsageStatsPermission()) {
            awayStartMsBySession.remove(current.id)
            refreshUsageProgress(current)
            return
        }
        val awayStart = awayStartMsBySession.remove(current.id) ?: return
        val awaySeconds = ((System.currentTimeMillis() - awayStart) / 1000L).toInt().coerceAtLeast(0)
        if (awaySeconds <= 0) return
        val observed = (current.observedUsageSeconds + awaySeconds).coerceAtMost(current.requiredUsageSeconds)
        if (observed > current.observedUsageSeconds) {
            viewModelScope.launch { rewardRepository.updateUsageProgress(current.id, observed) }
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun setStatusBanner(message: String) {
        _statusBanner.value = message
    }

    fun hasUsagePermission(): Boolean = usageTrackingRepository.hasUsageStatsPermission()

    fun openUsageAccessSettings() {
        usageTrackingRepository.openUsageAccessSettings()
    }

    fun openAppInfoSettings() {
        usageTrackingRepository.openAppInfoSettings()
    }

    fun unlockSuperOffer(onUnlocked: () -> Unit) {
        val cfg = appConfig.value
        val requiredGems = cfg.superOfferUnlockGems
        val requiredUsage = cfg.requiredUsageSeconds
        viewModelScope.launch {
            val snapshot = installationRepository.getInstalledLauncherPackages()
            val result = rewardRepository.unlockSuperOffer(
                requiredGems = requiredGems,
                requiredUsageSeconds = requiredUsage,
                initialPackages = snapshot
            )
            if (result.isSuccess) {
                onUnlocked()
            } else {
                _statusBanner.value = result.exceptionOrNull()?.message ?: "Not enough Gems."
            }
        }
    }

    fun recordAdWatched(sessionId: Long) {
        viewModelScope.launch {
            rewardRepository.recordAdWatched(sessionId)
            _statusBanner.value = "Ad completed! Now install the advertised app for Step 2."
        }
    }

    fun detectInstalledApp(session: OfferSessionEntity) {
        if (!session.adWatched) {
            _statusBanner.value = "Pehle Step 1 complete karein"
            return
        }
        val initialSet = session.initialPackagesSnapshot
            .split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()
        val detected = installationRepository.detectNewlyInstalledPackage(initialSet)
        if (detected != null) {
            viewModelScope.launch {
                rewardRepository.setTargetApplication(
                    sessionId = session.id,
                    packageName = detected.packageName,
                    appName = detected.appName
                )
                _statusBanner.value = "Installed ✓ (${detected.appName})"
            }
        } else {
            _statusBanner.value = "⚠️ If you already have this app installed, try a new offer app from the ad."
        }
    }

    fun refreshUsageProgress(session: OfferSessionEntity) {
        val current = latestSession(session)
        val targetPkg = current.targetPackage ?: return
        if (current.observedUsageSeconds >= current.requiredUsageSeconds) return
        // Without Usage Access permission the progress is updated by onScreenResumed() instead.
        if (!usageTrackingRepository.hasUsageStatsPermission()) return

        val observed = usageTrackingRepository
            .getForegroundUsageSeconds(targetPkg, current.createdAt)
            .coerceAtMost(current.requiredUsageSeconds)

        if (observed > current.observedUsageSeconds) {
            viewModelScope.launch {
                rewardRepository.updateUsageProgress(current.id, observed)
            }
        }
    }

    fun openTargetApp(packageName: String) {
        val launched = installationRepository.launchApp(packageName)
        if (!launched) {
            _statusBanner.value = "Unable to launch $packageName. Please open it from your launcher."
        }
    }

    fun claimOfferCoins(sessionId: Long) {
        val rewardCoins = appConfig.value.superOfferUnlockCoins
        viewModelScope.launch {
            val result = rewardRepository.completeOfferAndClaimCoins(sessionId, rewardCoins)
            _statusBanner.value = if (result.isSuccess) {
                "Offer Completed Successfully! ✓ +$rewardCoins Coins added!"
            } else {
                result.exceptionOrNull()?.message ?: "Could not claim coins."
            }
        }
    }
}
