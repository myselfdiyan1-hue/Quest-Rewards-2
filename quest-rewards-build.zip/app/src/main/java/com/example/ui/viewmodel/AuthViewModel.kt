package com.example.ui.viewmodel

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.config.TestConfig
import com.example.data.remote.AppConfig
import com.example.data.remote.FirebaseManager
import com.example.data.repository.RewardRepository
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

data class AuthUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class AuthViewModel(
    private val firebaseManager: FirebaseManager,
    private val rewardRepository: RewardRepository
) : ViewModel() {

    val currentUser: StateFlow<FirebaseUser?> = firebaseManager.authStateFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = firebaseManager.currentUser
        )

    private val _isLocalExploreMode = MutableStateFlow(false)
    val isLocalExploreMode: StateFlow<Boolean> = _isLocalExploreMode.asStateFlow()

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun enterLocalExploreMode() {
        viewModelScope.launch {
            rewardRepository.ensureLocalWelcomeBonus(
                welcomeCoins = TestConfig.WELCOME_BONUS_COINS,
                welcomeGems = TestConfig.WELCOME_BONUS_GEMS
            )
            _isLocalExploreMode.value = true
        }
    }

    fun exitLocalExploreMode() {
        _isLocalExploreMode.value = false
    }

    fun attemptAutoSignIn(context: Context) {
        if (Firebase.auth.currentUser != null) return
        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            return
        }
        if (clientId.contains("placeholderwebclientid")) return

        val credentialManager = CredentialManager.create(context)
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(true)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(true)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        viewModelScope.launch {
            try {
                val result = credentialManager.getCredential(context, request)
                handleCredential(result.credential)
            } catch (e: Exception) {
                Log.d(TAG, "Silent sign-in skipped: ${e.message}")
            }
        }
    }

    fun onGoogleSignInClicked(activity: Activity) {
        val clientId = try {
            activity.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            _uiState.value = AuthUiState(
                isLoading = false,
                errorMessage = "Google Sign-In configuration missing: default_web_client_id not found"
            )
            return
        }

        val credentialManager = CredentialManager.create(activity)
        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInOption)
            .build()

        _uiState.value = AuthUiState(isLoading = true, errorMessage = null)

        viewModelScope.launch {
            try {
                val result = credentialManager.getCredential(activity, request)
                handleCredential(result.credential)
                _isLocalExploreMode.value = false
                _uiState.value = AuthUiState(isLoading = false, errorMessage = null)
            } catch (e: GetCredentialCancellationException) {
                Log.w(TAG, "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
                _uiState.value = AuthUiState(isLoading = false, errorMessage = null)
            } catch (e: Exception) {
                Log.e(TAG, "Google Sign-In failed", e)
                _uiState.value = AuthUiState(
                    isLoading = false,
                    errorMessage = e.localizedMessage ?: "Unable to connect to Google Sign-In. Check your google-services.json configuration."
                )
            }
        }
    }

    private suspend fun handleCredential(credential: androidx.credentials.Credential) {
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
            val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
            val authResult = Firebase.auth.signInWithCredential(authCredential).await()
            val firebaseUser = authResult.user
            if (firebaseUser != null) {
                val config = runCatching { firebaseManager.observeAppConfig().first() }
                    .getOrDefault(AppConfig())
                val profile = firebaseManager.ensureUserDocument(firebaseUser, config)
                rewardRepository.syncFromRemoteProfile(profile)
            }
        } else {
            throw IllegalStateException("Unexpected credential type received.")
        }
    }

    fun signOut(context: Context, onComplete: () -> Unit = {}) {
        if (_isLocalExploreMode.value && Firebase.auth.currentUser == null) {
            _isLocalExploreMode.value = false
            onComplete()
            return
        }
        val credentialManager = CredentialManager.create(context)
        viewModelScope.launch {
            withContext(NonCancellable) {
                try {
                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to clear credential state: ${e.message}")
                } finally {
                    _isLocalExploreMode.value = false
                    rewardRepository.clearLocalUserData()
                    Firebase.auth.signOut()
                    onComplete()
                }
            }
        }
    }

    private companion object {
        const val TAG = "AuthViewModel"
    }
}
