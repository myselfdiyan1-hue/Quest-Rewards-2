package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface QuestDao {
    @Query("SELECT * FROM user_balance WHERE id = 1")
    fun observeBalance(): Flow<UserBalanceEntity?>

    @Query("SELECT * FROM user_balance WHERE id = 1")
    suspend fun getBalance(): UserBalanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBalance(balance: UserBalanceEntity)

    @Query("SELECT * FROM game_rounds WHERE roundId = :roundId")
    suspend fun getGameRound(roundId: String): GameRoundEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertGameRound(round: GameRoundEntity): Long

    @Query("SELECT * FROM offer_sessions ORDER BY createdAt DESC")
    fun observeOfferSessions(): Flow<List<OfferSessionEntity>>

    @Query("SELECT * FROM offer_sessions WHERE id = :sessionId")
    fun observeOfferSession(sessionId: Long): Flow<OfferSessionEntity?>

    @Query("SELECT * FROM offer_sessions WHERE id = :sessionId")
    suspend fun getOfferSession(sessionId: Long): OfferSessionEntity?

    @Query("SELECT * FROM offer_sessions WHERE status IN ('NOT_STARTED', 'IN_PROGRESS', 'PENDING_VERIFICATION') ORDER BY createdAt DESC LIMIT 1")
    fun observeActiveOfferSession(): Flow<OfferSessionEntity?>

    @Query("SELECT COUNT(*) FROM offer_sessions WHERE status = 'COMPLETED'")
    fun observeCompletedOfferCount(): Flow<Int>

    @Insert
    suspend fun insertOfferSession(session: OfferSessionEntity): Long

    @Update
    suspend fun updateOfferSession(session: OfferSessionEntity)

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun observeTransactions(): Flow<List<TransactionEntity>>

    @Insert
    suspend fun insertTransaction(tx: TransactionEntity): Long

    @Query("SELECT * FROM completed_tasks")
    fun observeCompletedTasks(): Flow<List<CompletedTaskEntity>>

    @Query("SELECT * FROM completed_tasks WHERE taskId = :taskId")
    suspend fun getCompletedTask(taskId: String): CompletedTaskEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCompletedTask(task: CompletedTaskEntity): Long

    @Query("DELETE FROM user_balance")
    suspend fun clearBalance()

    @Query("DELETE FROM game_rounds")
    suspend fun clearGameRounds()

    @Query("DELETE FROM offer_sessions")
    suspend fun clearOfferSessions()

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()

    @Query("DELETE FROM completed_tasks")
    suspend fun clearCompletedTasks()
}
