package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.UnityBannerAd
import com.example.ads.UnityRewardedAdManager
import com.example.ui.components.CoinBadge
import com.example.ui.components.CoinVectorIcon
import com.example.ui.components.GemBadge
import com.example.ui.components.InitialsAvatar
import com.example.ui.components.QuestCard
import com.example.ui.components.UnityAdsConfigDialog
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.GemCyan
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceVariant
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    mainViewModel: MainViewModel,
    adManager: UnityRewardedAdManager,
    firebaseUser: FirebaseUser?,
    onOpenWallet: () -> Unit,
    onOpenSuperOffer: () -> Unit,
    onOpenImageFinder: () -> Unit,
    onOpenTasks: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenHistory: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    val balance by mainViewModel.balance.collectAsStateWithLifecycle()
    val userProfile by mainViewModel.userProfile.collectAsStateWithLifecycle()
    val appConfig by mainViewModel.appConfig.collectAsStateWithLifecycle()
    val tasks by mainViewModel.tasks.collectAsStateWithLifecycle()

    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showReferDialog by remember { mutableStateOf(false) }
    var showAccountConnectDialog by remember { mutableStateOf(false) }
    var showUnityConfigDialog by remember { mutableStateOf(false) }

    val displayName = userProfile?.displayName?.ifBlank { null }
        ?: firebaseUser?.displayName
        ?: "Quest Player"
    val email = userProfile?.email?.ifBlank { null }
        ?: firebaseUser?.email
        ?: "player@questrewards.app"
    val uid = userProfile?.uid?.ifBlank { null } ?: firebaseUser?.uid ?: "GUEST"
    val referralCode = "QUEST-${uid.take(6).uppercase()}"

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CardWhite
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(listOf(PrimaryBlue, PurpleAccent))
                        )
                        .padding(20.dp)
                ) {
                    InitialsAvatar(name = displayName, size = 54.dp, backgroundColor = Color.White)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = displayName,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                    Text(
                        text = email,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }

                Spacer(Modifier.height(8.dp))

                NavigationDrawerItem(
                    label = { Text("My Profile") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        onOpenProfile()
                    },
                    icon = { Icon(Icons.Filled.AccountCircle, contentDescription = "My Profile") },
                    modifier = Modifier.testTag("drawer_profile")
                )
                NavigationDrawerItem(
                    label = { Text("Privacy Policy") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        showPrivacyDialog = true
                    },
                    icon = { Icon(Icons.Filled.PrivacyTip, contentDescription = "Privacy Policy") },
                    modifier = Modifier.testTag("drawer_privacy")
                )
                NavigationDrawerItem(
                    label = { Text("Refer and Earn") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        showReferDialog = true
                    },
                    icon = { Icon(Icons.Filled.CardGiftcard, contentDescription = "Refer and Earn") },
                    modifier = Modifier.testTag("drawer_refer")
                )
                NavigationDrawerItem(
                    label = { Text("Account Connect") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        showAccountConnectDialog = true
                    },
                    icon = { Icon(Icons.Filled.Link, contentDescription = "Account Connect") },
                    modifier = Modifier.testTag("drawer_connect")
                )
                NavigationDrawerItem(
                    label = { Text("History") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        onOpenHistory()
                    },
                    icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                    modifier = Modifier.testTag("drawer_history")
                )
                NavigationDrawerItem(
                    label = { Text("Unity Ads Config") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        showUnityConfigDialog = true
                    },
                    icon = { Icon(Icons.Filled.Tune, contentDescription = "Unity Ads Config") },
                    modifier = Modifier.testTag("drawer_unity_ads")
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = BorderSubtle)

                NavigationDrawerItem(
                    label = { Text("Logout") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        onLogout()
                    },
                    icon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Logout") },
                    modifier = Modifier.testTag("drawer_logout")
                )
            }
        }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MainBackground),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Top Gradient Header
            item {
                Surface(
                    color = HeaderBackground,
                    shadowElevation = 4.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 20.dp, vertical = 16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { scope.launch { drawerState.open() } },
                                    modifier = Modifier.testTag("menu_drawer_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Menu,
                                        contentDescription = "Open Menu",
                                        tint = PrimaryText
                                    )
                                }
                                Column {
                                    Text(
                                        text = "Quest Rewards",
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = PrimaryText
                                    )
                                    Text(
                                        text = "Official Live Rewards",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SecondaryText
                                    )
                                }
                            }

                            GemBadge(amountText = "${balance.gems}", animatePulse = true)
                        }

                        Spacer(Modifier.height(14.dp))

                        // Balance Hero Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(PrimaryBlue, SecondaryBlue, PurpleAccent)
                                    )
                                )
                                .padding(18.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Available Coins",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CoinVectorIcon(size = 28.dp, animatePulse = true)
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = "${balance.coins}",
                                            style = MaterialTheme.typography.displayLarge,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = Color.White.copy(alpha = 0.18f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.CheckCircle,
                                                contentDescription = null,
                                                tint = Color(0xFF6EE7B7),
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(Modifier.width(6.dp))
                                            Text(
                                                text = if (firebaseUser != null) "Account Synced & Active" else "Local Preview Mode",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }

                                Button(
                                    onClick = onOpenWallet,
                                    modifier = Modifier.testTag("home_wallet_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CardWhite,
                                        contentColor = PrimaryBlue
                                    )
                                ) {
                                    Text(
                                        text = "Wallet",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // FEATURED / ACTIVE: SUPER OFFER
            item {
                Spacer(Modifier.height(18.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(PurpleAccent, PrimaryBlue)
                            )
                        )
                        .clickable(onClick = onOpenSuperOffer)
                        .testTag("home_super_offer_card")
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = OrangeAccent
                            ) {
                                Text(
                                    text = "FEATURED / ACTIVE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color.White
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CoinVectorIcon(size = 16.dp, animatePulse = true)
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = "+${appConfig.superOfferUnlockCoins} Coins",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = PrimaryText
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        Text(
                            text = "SUPER OFFER",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Unlock with ${appConfig.superOfferUnlockGems} Gems • Watch Ad, Install & Use App",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            // PLAY & EARN: IMAGE FINDER
            item {
                Spacer(Modifier.height(16.dp))
                QuestCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    onClick = onOpenImageFinder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = GemCyan.copy(alpha = 0.14f)
                        ) {
                            Text(
                                text = "PLAY & EARN",
                                style = MaterialTheme.typography.labelSmall,
                                color = GemCyan,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        GemBadge(
                            amountText = "+${appConfig.gemRewardPerRound} Gem / Win",
                            animatePulse = true
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    Text(
                        text = "IMAGE FINDER",
                        style = MaterialTheme.typography.headlineSmall,
                        color = PrimaryText
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Earn Gems to Unlock Super Offers",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SecondaryText
                    )

                    Spacer(Modifier.height(14.dp))

                    Button(
                        onClick = onOpenImageFinder,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("play_image_finder_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryBlue,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "Play Game",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            // Tasks section header
            item {
                Spacer(Modifier.height(22.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tasks",
                        style = MaterialTheme.typography.headlineSmall,
                        color = PrimaryText
                    )
                    TextButton(
                        onClick = onOpenTasks,
                        modifier = Modifier.testTag("home_view_all_tasks")
                    ) {
                        Text(
                            text = "View All",
                            style = MaterialTheme.typography.labelLarge,
                            color = PrimaryBlue
                        )
                    }
                }
            }

            if (tasks.isEmpty()) {
                item {
                    QuestCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = SurfaceVariant,
                                modifier = Modifier.size(52.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.Assignment,
                                        contentDescription = null,
                                        tint = SecondaryText
                                    )
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = "No Tasks Active",
                                style = MaterialTheme.typography.titleMedium,
                                color = PrimaryText
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Tasks added from Admin Panel will appear here automatically.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SecondaryText
                            )
                        }
                    }
                }
            } else {
                items(tasks.take(4), key = { it.id }) { task ->
                    QuestCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 6.dp),
                        onClick = onOpenTasks
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = PrimaryBlue.copy(alpha = 0.1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.AutoAwesome,
                                        contentDescription = null,
                                        tint = PrimaryBlue,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = task.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = PrimaryText
                                    )
                                    Text(
                                        text = task.category,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SecondaryText
                                    )
                                }
                            }
                            CoinBadge(amountText = "+${task.rewardCoins}")
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clickable { showUnityConfigDialog = true }
                ) {
                    UnityBannerAd()
                }
            }
        }
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Policy") },
            text = {
                Column {
                    Text(
                        text = "Last updated: October 2026",
                        style = MaterialTheme.typography.labelMedium,
                        color = PrimaryBlue
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Quest Rewards collects only your Google account profile (name, email, UID) to sync coins, gems, and payout requests securely with Cloud Firestore. Usage stats permission is used strictly when you unlock and verify an active Super Offer.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SecondaryText
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showPrivacyDialog = false }) {
                    Text("I Understand")
                }
            }
        )
    }

    if (showReferDialog) {
        AlertDialog(
            onDismissRequest = { showReferDialog = false },
            title = { Text("Earn 100 Coins for Every Friend!") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Share your referral code with friends so they can join Quest Rewards.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SecondaryText
                    )
                    Spacer(Modifier.height(14.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceVariant,
                        border = BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "YOUR REFERRAL CODE",
                                style = MaterialTheme.typography.labelSmall,
                                color = SecondaryText
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = referralCode,
                                style = MaterialTheme.typography.headlineSmall,
                                color = PrimaryBlue
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "Join Quest Rewards & earn instant rewards! Use my referral code: $referralCode"
                        )
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share with Friends"))
                }) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Share with Friends")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReferDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showAccountConnectDialog) {
        AlertDialog(
            onDismissRequest = { showAccountConnectDialog = false },
            title = { Text("Account Connect") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Display Name: $displayName", style = MaterialTheme.typography.bodyMedium)
                    Text("Email: $email", style = MaterialTheme.typography.bodyMedium)
                    Text("Account ID: $uid", style = MaterialTheme.typography.bodySmall, color = SecondaryText)
                }
            },
            confirmButton = {
                Button(onClick = { showAccountConnectDialog = false }) {
                    Text("Done")
                }
            }
        )
    }

    if (showUnityConfigDialog) {
        UnityAdsConfigDialog(
            adManager = adManager,
            onDismiss = { showUnityConfigDialog = false }
        )
    }
}
