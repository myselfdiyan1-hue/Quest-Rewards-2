package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdState
import com.example.ads.UnityRewardedAdManager
import com.example.data.local.OfferStatus
import com.example.ui.components.QuestCard
import com.example.ui.components.UnityAdsConfigDialog
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceVariant
import com.example.ui.viewmodel.SuperOfferViewModel
import kotlinx.coroutines.delay

private tailrec fun Context.findOfferActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findOfferActivity()
    else -> null
}

@Composable
fun SuperOfferDetailsScreen(
    viewModel: SuperOfferViewModel,
    adManager: UnityRewardedAdManager,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context.findOfferActivity()
    val lifecycleOwner = LocalLifecycleOwner.current

    val activeSession by viewModel.activeOfferSession.collectAsStateWithLifecycle()
    val sessions by viewModel.offerSessions.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val adState by adManager.adState.collectAsStateWithLifecycle()
    val isUnityInitialized by adManager.isInitializedState.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    var showUnityConfigDialog by remember { mutableStateOf(false) }

    val session = activeSession ?: sessions.firstOrNull()

    var hasUsagePerm by remember { mutableStateOf(viewModel.hasUsagePermission()) }

    // Re-check newly installed package and usage on resume; track time away on stop
    DisposableEffect(lifecycleOwner, session?.id, session?.targetPackage) {
        val observer = LifecycleEventObserver { _, event ->
            val s = session ?: return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    hasUsagePerm = viewModel.hasUsagePermission()
                    if (s.adWatched && s.targetPackage == null) {
                        viewModel.detectInstalledApp(s)
                    }
                    if (s.targetPackage != null) {
                        viewModel.onScreenResumed(s)
                    }
                }
                Lifecycle.Event.ON_STOP -> {
                    if (s.targetPackage != null) viewModel.onScreenStopped(s)
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Periodic usage refresh while on this screen
    LaunchedEffect(session?.id, session?.targetPackage) {
        val current = session ?: return@LaunchedEffect
        if (current.targetPackage != null && current.status != OfferStatus.COMPLETED) {
            while (true) {
                hasUsagePerm = viewModel.hasUsagePermission()
                viewModel.refreshUsageProgress(current)
                delay(1000L)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Surface(color = HeaderBackground, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("super_offer_details_back")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PrimaryText)
                }
                Text(
                    text = "Super Offer Details",
                    style = MaterialTheme.typography.headlineSmall,
                    color = PrimaryText
                )
            }
        }

        if (session == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No active offer session found.", color = SecondaryText)
            }
            return
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(PrimaryBlue, PurpleAccent)))
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Gems Collected & Unlocked",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Color.White.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = session.status.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "\uD83C\uDF81 Guaranteed ${appConfig.superOfferUnlockCoins} Coins Reward!",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White
                    )
                }
            }

            statusBanner?.let { banner ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = OrangeAccent.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, OrangeAccent.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = banner,
                        style = MaterialTheme.typography.bodySmall,
                        color = PrimaryText,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // STEP 1: Watch a video Ad
            QuestCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("STEP 1: Watch a video Ad", style = MaterialTheme.typography.titleMedium, color = PrimaryText)
                    if (session.adWatched) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = "Done", tint = SuccessGreen)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (session.adWatched) "Completed ✓" else "Watch the complete rewarded video Ad to unlock Step 2.",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (session.adWatched) SuccessGreen else SecondaryText
                )
                if (!session.adWatched) {
                    Spacer(Modifier.height(10.dp))
                    val needsGameId = !adManager.isGameIdConfigured() && !isUnityInitialized
                    val btnLabel = when {
                        needsGameId -> "Configure Unity Game ID"
                        adState is AdState.Loading -> "Loading Unity Ad..."
                        adState is AdState.Showing -> "Playing Ad..."
                        else -> "Watch Ad"
                    }
                    Button(
                        onClick = {
                            if (activity != null) {
                                adManager.showRewardedAd(
                                    activity = activity,
                                    onRewarded = { viewModel.recordAdWatched(session.id) },
                                    onNotCompleted = { msg -> viewModel.setStatusBanner(msg) },
                                    onNeedsGameIdConfig = { showUnityConfigDialog = true }
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("step1_watch_ad_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(btnLabel)
                    }
                    if (adState is AdState.Error || needsGameId) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = if (needsGameId) {
                                "Unity Ads SDK is ready — tap above to enter your numeric Unity Game ID for live Test Ads."
                            } else {
                                (adState as? AdState.Error)?.message ?: "Unity Ad error"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = OrangeAccent
                        )
                        if (!needsGameId) {
                            TextButton(onClick = { showUnityConfigDialog = true }) {
                                Text("Edit Unity Ads Config")
                            }
                        }
                    }
                }
            }

            // STEP 2: Install the app
            QuestCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("STEP 2: Install the app", style = MaterialTheme.typography.titleMedium, color = PrimaryText)
                    if (session.targetPackage != null) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = "Installed", tint = SuccessGreen)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (session.targetPackage != null) {
                        "Installed ✓ (${session.targetAppName ?: session.targetPackage})"
                    } else if (!session.adWatched) {
                        "Pehle Step 1 complete karein"
                    } else {
                        "Install the partner app from the Ad, then tap Detect Installed App."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (session.targetPackage != null) SuccessGreen else SecondaryText
                )
                if (session.targetPackage == null) {
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.detectInstalledApp(session) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("step2_detect_install_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Check Installed App")
                    }
                }
            }

            // STEP 3: Use app for 2 minutes
            val remaining = (session.requiredUsageSeconds - session.observedUsageSeconds).coerceAtLeast(0)
            val progress = (session.observedUsageSeconds.toFloat() / session.requiredUsageSeconds.coerceAtLeast(1)).coerceIn(0f, 1f)
            QuestCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("STEP 3: Use app for 2 minutes", style = MaterialTheme.typography.titleMedium, color = PrimaryText)
                    if (remaining == 0 && session.targetPackage != null) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = "Usage Met", tint = SuccessGreen)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "usage_progress / App Usage Progress ${session.observedUsageSeconds}s / ${session.requiredUsageSeconds}s",
                    style = MaterialTheme.typography.labelLarge,
                    color = PrimaryBlue
                )
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50)),
                    color = PrimaryBlue,
                    trackColor = SurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (remaining > 0) "⏳ Ab $remaining second aur use karna hai app ko!" else "Usage requirement met ✓",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (remaining > 0) OrangeAccent else SuccessGreen
                )

                val targetPkg = session.targetPackage
                if (!hasUsagePerm) {
                    Spacer(Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = PrimaryBlue.copy(alpha = 0.08f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Usage access is OFF, so only time spent inside the offer app (away from this screen) is counted.",
                                style = MaterialTheme.typography.labelSmall,
                                color = PrimaryBlue
                            )
                            if (viewModel.mayNeedRestrictedSettingsUnlock()) {
                                Text(
                                    text = "If \"Access denied for this app\" shows: App info → ⋮ (top-right) → Allow restricted settings, then enable Usage access.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SecondaryText
                                )
                                TextButton(onClick = { viewModel.openAppInfoSettings() }) {
                                    Text("1. Open App info (Allow restricted settings)", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            TextButton(onClick = { viewModel.openUsageAccessSettings() }) {
                                Text("2. Open Usage access", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                if (targetPkg != null) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { viewModel.openTargetApp(targetPkg) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("step3_open_app_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Open App")
                        }
                        OutlinedButton(
                            onClick = { viewModel.refreshUsageProgress(session) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Refresh Usage")
                        }
                    }
                }
            }

            // STEP 4: Collect Coins
            val readyToClaim = session.adWatched &&
                session.targetPackage != null &&
                session.observedUsageSeconds >= session.requiredUsageSeconds &&
                !session.coinsRewarded
            QuestCard(modifier = Modifier.fillMaxWidth()) {
                Text("STEP 4: Collect Coins", style = MaterialTheme.typography.titleMedium, color = PrimaryText)
                Spacer(Modifier.height(8.dp))
                if (session.coinsRewarded || session.status == OfferStatus.COMPLETED) {
                    Text(
                        text = "Offer Completed Successfully! ✓",
                        style = MaterialTheme.typography.titleSmall,
                        color = SuccessGreen
                    )
                } else {
                    Button(
                        onClick = { viewModel.claimOfferCoins(session.id) },
                        enabled = readyToClaim,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("step4_claim_coins_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SuccessGreen,
                            contentColor = Color.White
                        )
                    ) {
                        Text("Claim ${appConfig.superOfferUnlockCoins} Coins", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Warnings
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ErrorRed.copy(alpha = 0.08f),
                border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Installing apps other than the advertised app will result in permanent account ban and withdrawal rejection.",
                            style = MaterialTheme.typography.bodySmall,
                            color = ErrorRed
                        )
                    }
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = OrangeAccent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Don't delete the installed app for at least 3 days to preserve reward eligibility.",
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryText
                        )
                    }
                }
            }
        }
    }

    if (showUnityConfigDialog) {
        UnityAdsConfigDialog(
            adManager = adManager,
            onDismiss = { showUnityConfigDialog = false }
        )
    }
}
