package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CoinVectorIcon
import com.example.ui.components.QuestCard
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceVariant
import com.example.ui.viewmodel.MainViewModel
import java.util.Locale

@Composable
fun WalletScreen(
    mainViewModel: MainViewModel,
    onSelectMethod: (String) -> Unit
) {
    val balance by mainViewModel.balance.collectAsStateWithLifecycle()
    val userProfile by mainViewModel.userProfile.collectAsStateWithLifecycle()
    val payoutMethods by mainViewModel.payoutMethods.collectAsStateWithLifecycle()

    val isBlocked = userProfile?.isBlocked == true
    val approxRupees = String.format(Locale.US, "%.2f", balance.coins / 100.0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
    ) {
        Surface(color = HeaderBackground, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Wallet & Withdraw",
                    style = MaterialTheme.typography.headlineMedium,
                    color = PrimaryText
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Balance Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(PrimaryBlue, PurpleAccent)))
                        .padding(20.dp)
                ) {
                    Column {
                        Text(
                            text = "TOTAL AVAILABLE COINS",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CoinVectorIcon(size = 32.dp, animatePulse = true)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = "${balance.coins}",
                                style = MaterialTheme.typography.displayLarge,
                                color = Color.White
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "≈ ₹$approxRupees INR",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFFFFE57F)
                        )
                        Spacer(Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Color.White.copy(alpha = 0.18f)
                        ) {
                            Text(
                                text = "Conversion Rate: 1,000 Coins = ₹10",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            if (isBlocked) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = ErrorRed.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Block, contentDescription = null, tint = ErrorRed)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = "Account Blocked by Admin. Withdrawals and reward claims are currently restricted.",
                                style = MaterialTheme.typography.bodySmall,
                                color = ErrorRed
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "Select Payout Method",
                    style = MaterialTheme.typography.headlineSmall,
                    color = PrimaryText
                )
            }

            items(payoutMethods, key = { it.id }) { method ->
                val minCoins = method.minCoins.coerceAtLeast(1)
                val progress = (balance.coins.toFloat() / minCoins.toFloat()).coerceIn(0f, 1f)
                val icon = when {
                    method.id.contains("UPI", ignoreCase = true) || method.icon.contains("upi", ignoreCase = true) -> Icons.Filled.QrCode2
                    method.id.contains("BANK", ignoreCase = true) || method.icon.contains("bank", ignoreCase = true) -> Icons.Filled.AccountBalance
                    else -> Icons.Filled.AccountBalanceWallet
                }

                QuestCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payout_method_${method.id}"),
                    onClick = { if (!isBlocked) onSelectMethod(method.id) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = PrimaryBlue.copy(alpha = 0.1f)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = method.name,
                                    tint = PrimaryBlue,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = method.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PrimaryText
                                )
                                Text(
                                    text = "Min Payout: ${method.minCoins} Coins",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SecondaryText
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Open",
                            tint = SecondaryText
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(RoundedCornerShape(50)),
                        color = if (progress >= 1f) SuccessGreen else PrimaryBlue,
                        trackColor = SurfaceVariant
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "100% Safe & Secure Instant Payouts",
                        style = MaterialTheme.typography.labelMedium,
                        color = SecondaryText,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
