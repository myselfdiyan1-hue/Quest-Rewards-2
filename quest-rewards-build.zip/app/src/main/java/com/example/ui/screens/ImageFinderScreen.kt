package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.AdState
import com.example.ads.UnityRewardedAdManager
import com.example.config.TestConfig
import com.example.ui.components.GemVectorIcon
import com.example.ui.components.ImageFinderObjectVector
import com.example.ui.components.QuestCard
import com.example.ui.components.UnityAdsConfigDialog
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.GemCyan
import com.example.ui.theme.MainBackground
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceVariant
import com.example.ui.viewmodel.ImageFinderViewModel

private tailrec fun Context.findGameActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findGameActivity()
    else -> null
}

@Composable
fun ImageFinderScreen(
    viewModel: ImageFinderViewModel,
    adManager: UnityRewardedAdManager,
    gemRewardPerRound: Int = TestConfig.GEM_REWARD_PER_ROUND,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context.findGameActivity()
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val adState by adManager.adState.collectAsStateWithLifecycle()
    val isUnityInitialized by adManager.isInitializedState.collectAsStateWithLifecycle()
    var showUnityConfigDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("image_finder_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = PrimaryText
                        )
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Image Finder",
                                style = MaterialTheme.typography.headlineSmall,
                                color = PrimaryText
                            )
                            Spacer(Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = PrimaryBlue
                            ) {
                                Text(
                                    text = "LVL ${state.level}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Text(
                            text = "3 Finds = Gem Reward",
                            style = MaterialTheme.typography.bodySmall,
                            color = SecondaryText
                        )
                    }
                }

                Row {
                    IconButton(
                        onClick = { viewModel.togglePause() },
                        modifier = Modifier.testTag("image_finder_pause")
                    ) {
                        Icon(
                            imageVector = if (state.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                            contentDescription = "Pause Game",
                            tint = PrimaryText
                        )
                    }
                    IconButton(
                        onClick = {
                            if (activity != null) {
                                adManager.showInterstitialIfReady(activity) {
                                    viewModel.startNewCycle()
                                }
                            } else {
                                viewModel.startNewCycle()
                            }
                        },
                        modifier = Modifier.testTag("image_finder_restart")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Restart Game",
                            tint = PrimaryText
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Goal & Timer Bar
            QuestCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "FIND GOAL: 3 TARGETS",
                            style = MaterialTheme.typography.labelMedium,
                            color = PrimaryText,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            repeat(3) { idx ->
                                val filled = idx < state.findsCount
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(if (filled) SuccessGreen else BorderSubtle)
                                )
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (state.timeLeftSeconds <= 8) ErrorRed.copy(alpha = 0.14f) else SurfaceVariant
                        ) {
                            Text(
                                text = "⏳ ${state.timeLeftSeconds}s",
                                style = MaterialTheme.typography.titleSmall,
                                color = if (state.timeLeftSeconds <= 8) ErrorRed else PrimaryBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Reward: 1 Gem / 3 Wins",
                            style = MaterialTheme.typography.bodySmall,
                            color = SecondaryText
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            if (state.isRoundComplete) {
                QuestCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        GemVectorIcon(size = 64.dp, animatePulse = true)
                        Spacer(Modifier.height(12.dp))

                        if (state.gemCollected) {
                            AnimatedVisibility(visible = true, enter = scaleIn()) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "+1 GEM COLLECTED! 💎",
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = GemCyan,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = "Ad watched successfully! Gems added to your balance.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = SuccessGreen,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = {
                                    if (activity != null) {
                                        adManager.showInterstitialIfReady(activity) {
                                            viewModel.startNewCycle()
                                        }
                                    } else {
                                        viewModel.startNewCycle()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("play_next_round_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Play Next Round")
                            }
                        } else {
                            Text(
                                text = "3/3 Images Found Successfully!",
                                style = MaterialTheme.typography.headlineSmall,
                                color = PrimaryText,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "Watch a quick Ad to add Gems directly to your balance!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SecondaryText,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(18.dp))

                            val needsGameId = !adManager.isGameIdConfigured() && !isUnityInitialized
                            val adButtonText = when {
                                needsGameId -> "CONFIGURE UNITY GAME ID"
                                adState is AdState.Loading -> "Loading Ad..."
                                adState is AdState.Ready -> "COLLECT GEMS (WATCH AD)"
                                adState is AdState.Showing -> "Playing Ad..."
                                adState is AdState.Error -> "COLLECT GEMS (WATCH AD)"
                                adState is AdState.Idle -> "Loading Ad..."
                                else -> "COLLECT GEMS (WATCH AD)"
                            }

                            Button(
                                onClick = {
                                    if (activity != null) {
                                        adManager.showRewardedAd(
                                            activity = activity,
                                            onRewarded = {
                                                viewModel.onRewardedAdCompleted(gemRewardPerRound)
                                            },
                                            onNeedsGameIdConfig = {
                                                showUnityConfigDialog = true
                                            }
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(54.dp)
                                    .testTag("collect_gems_watch_ad_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PurpleAccent,
                                    contentColor = Color.White
                                )
                            ) {
                                Text(
                                    text = adButtonText,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (adState is AdState.Error || needsGameId) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = if (needsGameId) {
                                        "Unity Ads SDK integrated — tap above to enter your numeric Unity Game ID for live Test Ads."
                                    } else {
                                        (adState as AdState.Error).message + " — Tap button to retry loading Ad."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = OrangeAccent,
                                    textAlign = TextAlign.Center
                                )
                                if (!needsGameId) {
                                    TextButton(onClick = { showUnityConfigDialog = true }) {
                                        Text("Edit Unity Ads Config")
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (state.isGameOver) {
                QuestCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "⏳ Time's Up!",
                            style = MaterialTheme.typography.headlineMedium,
                            color = ErrorRed
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "You found ${state.findsCount}/3 objects. Try again to earn your Gem!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SecondaryText,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(18.dp))
                        Button(
                            onClick = {
                                if (activity != null) {
                                    adManager.showInterstitialIfReady(activity) {
                                        viewModel.startNewCycle()
                                    }
                                } else {
                                    viewModel.startNewCycle()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("game_over_restart_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("Restart")
                        }
                    }
                }
            } else {
                // Target Prompt Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(PrimaryBlue, PurpleAccent)))
                        .padding(18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "FIND THIS MATCHING OBJECT",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.9f),
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = CardWhite,
                            modifier = Modifier.size(92.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(10.dp)) {
                                ImageFinderObjectVector(
                                    type = state.target,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = state.target.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                state.feedbackMessage?.let { msg ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = if (state.isErrorFeedback) ErrorRed.copy(alpha = 0.14f) else SuccessGreen.copy(alpha = 0.14f),
                        border = BorderStroke(
                            1.dp,
                            if (state.isErrorFeedback) ErrorRed.copy(alpha = 0.4f) else SuccessGreen.copy(alpha = 0.4f)
                        )
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (state.isErrorFeedback) ErrorRed else SuccessGreen,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                }

                // 2 rows x 3 columns grid of 6 objects
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    state.options.chunked(3).forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            rowItems.forEach { item ->
                                QuestCard(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(0.95f)
                                        .testTag("option_${item.name.lowercase()}"),
                                    onClick = { viewModel.onOptionTapped(item) }
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        ImageFinderObjectVector(
                                            type = item,
                                            modifier = Modifier.size(60.dp)
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = item.displayName,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = PrimaryText
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Pause Overlay
        if (state.isPaused) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(PrimaryText.copy(alpha = 0.78f))
                    .clickable { viewModel.togglePause() }
                    .testTag("game_paused_overlay"),
                contentAlignment = Alignment.Center
            ) {
                QuestCard(modifier = Modifier.padding(32.dp)) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Game Paused",
                            style = MaterialTheme.typography.headlineMedium,
                            color = PrimaryText
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Tap to Resume",
                            style = MaterialTheme.typography.bodyLarge,
                            color = PrimaryBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (showUnityConfigDialog) {
            UnityAdsConfigDialog(
                adManager = adManager,
                onDismiss = { showUnityConfigDialog = false }
            )
        }
    }
}
