package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.BuildConfig
import com.example.ads.UnityAdsConfig
import com.example.ads.UnityRewardedAdManager
import com.example.ui.components.CoinVectorIcon
import com.example.ui.components.GemVectorIcon
import com.example.ui.components.InitialsAvatar
import com.example.ui.components.QuestCard
import com.example.ui.components.UnityAdsConfigDialog
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.auth.FirebaseUser

@Composable
fun ProfileScreen(
    mainViewModel: MainViewModel,
    adManager: UnityRewardedAdManager,
    firebaseUser: FirebaseUser?,
    onBack: () -> Unit,
    onOpenHistory: () -> Unit,
    onLogoutOrSwitch: () -> Unit
) {
    val context = LocalContext.current
    val balance by mainViewModel.balance.collectAsStateWithLifecycle()
    val userProfile by mainViewModel.userProfile.collectAsStateWithLifecycle()
    val isUnityInitialized by adManager.isInitializedState.collectAsStateWithLifecycle()

    val displayName = userProfile?.displayName?.ifBlank { null }
        ?: firebaseUser?.displayName
        ?: "Quest Player"
    val email = userProfile?.email?.ifBlank { null }
        ?: firebaseUser?.email
        ?: "player@questrewards.app"
    val photoUrl = userProfile?.photoUrl ?: firebaseUser?.photoUrl?.toString()

    var showPrivacy by remember { mutableStateOf(false) }
    var showSupport by remember { mutableStateOf(false) }
    var showRules by remember { mutableStateOf(false) }
    var showUnityConfig by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Surface(color = HeaderBackground, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("profile_back")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PrimaryText)
                }
                Text(
                    text = "Profile & Account",
                    style = MaterialTheme.typography.headlineSmall,
                    color = PrimaryText
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // User Identity Card
            QuestCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        if (!photoUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = photoUrl,
                                contentDescription = "Google Avatar",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                            )
                        } else {
                            InitialsAvatar(name = displayName, size = 56.dp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(
                                text = displayName,
                                style = MaterialTheme.typography.titleLarge,
                                color = PrimaryText
                            )
                            Text(
                                text = email,
                                style = MaterialTheme.typography.bodySmall,
                                color = SecondaryText
                            )
                            Spacer(Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = SuccessGreen.copy(alpha = 0.14f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Verified,
                                        contentDescription = null,
                                        tint = SuccessGreen,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = if (firebaseUser != null) "GOOGLE VERIFIED" else "LOCAL PREVIEW",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SuccessGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    TextButton(onClick = onLogoutOrSwitch) {
                        Icon(Icons.Filled.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Switch")
                    }
                }
            }

            // Coin & Gem cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuestCard(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CoinVectorIcon(size = 24.dp, animatePulse = true)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "${balance.coins}",
                            style = MaterialTheme.typography.headlineSmall,
                            color = PrimaryText
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Available Coins",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryText
                    )
                }

                QuestCard(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GemVectorIcon(size = 24.dp, animatePulse = true)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "${balance.gems}",
                            style = MaterialTheme.typography.headlineSmall,
                            color = PrimaryText
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Gems for Offers",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryText
                    )
                }
            }

            // Rows
            val unityReady = isUnityInitialized || UnityAdsConfig.isConfigured(context)
            QuestCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_unity_ads_card"),
                onClick = { showUnityConfig = true }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.Tune, contentDescription = null, tint = PrimaryBlue)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "LevelPlay Ads Setup & Status",
                                style = MaterialTheme.typography.titleSmall,
                                color = PrimaryText
                            )
                            Text(
                                text = if (unityReady) {
                                    "App Key: ${UnityAdsConfig.getEffectiveAppKey(context)}"
                                } else {
                                    "Tap to enter LevelPlay App Key"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = SecondaryText
                            )
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = (if (unityReady) SuccessGreen else OrangeAccent).copy(alpha = 0.14f)
                    ) {
                        Text(
                            text = if (unityReady) "ACTIVE" else "SETUP",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (unityReady) SuccessGreen else OrangeAccent,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
            if (BuildConfig.DEBUG) {
                androidx.compose.material3.OutlinedButton(
                    onClick = { adManager.launchTestSuite(context) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_open_test_suite_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Tune,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Open Ad Test Suite", style = MaterialTheme.typography.labelLarge)
                }
            }
            ProfileActionRow(
                icon = Icons.Filled.History,
                title = "Earnings & Withdrawal History",
                onClick = onOpenHistory
            )
            ProfileActionRow(
                icon = Icons.Filled.PrivacyTip,
                title = "Privacy Policy",
                onClick = { showPrivacy = true }
            )
            ProfileActionRow(
                icon = Icons.Filled.Email,
                title = "Contact Support",
                onClick = { showSupport = true }
            )
            QuestCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Shield, contentDescription = null, tint = SuccessGreen)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = "Account Protection",
                            style = MaterialTheme.typography.titleSmall,
                            color = PrimaryText
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = SuccessGreen.copy(alpha = 0.14f)
                    ) {
                        Text(
                            text = "VERIFIED",
                            style = MaterialTheme.typography.labelSmall,
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
            ProfileActionRow(
                icon = Icons.Filled.Gavel,
                title = "Platform Rules & Reward Rates",
                onClick = { showRules = true }
            )

            Button(
                onClick = onLogoutOrSwitch,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("profile_logout_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ErrorRed,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Log Out / Switch Account", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showPrivacy) {
        AlertDialog(
            onDismissRequest = { showPrivacy = false },
            title = { Text("Privacy Policy") },
            text = {
                Text("Last updated: October 2026\n\nQuest Rewards securely stores your profile, rewards, and payout requests in Firebase Firestore.")
            },
            confirmButton = {
                Button(onClick = { showPrivacy = false }) { Text("I Understand") }
            }
        )
    }

    if (showSupport) {
        AlertDialog(
            onDismissRequest = { showSupport = false },
            title = { Text("Contact Support") },
            text = {
                Text("Need help with an offer or withdrawal? Reach out to support@questrewards.app and include your Account ID.")
            },
            confirmButton = {
                Button(onClick = {
                    showSupport = false
                    runCatching {
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:support@questrewards.app")
                            putExtra(Intent.EXTRA_SUBJECT, "Quest Rewards Support")
                        }
                        context.startActivity(intent)
                    }
                }) {
                    Text("Send Email")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSupport = false }) { Text("Close") }
            }
        )
    }

    if (showRules) {
        AlertDialog(
            onDismissRequest = { showRules = false },
            title = { Text("Platform Rules & Reward Rates") },
            text = {
                Text("• Image Finder: 3 Finds = 1 Gem (watch full Ad).\n• Super Offer: 2 Gems unlock -> Watch Ad, install advertised app, use for 120s -> +10 Coins.\n• Conversion Rate: 1,000 Coins = ₹10 INR.\n• Installing apps other than the advertised app results in account ban.")
            },
            confirmButton = {
                Button(onClick = { showRules = false }) { Text("Got It") }
            }
        )
    }

    if (showUnityConfig) {
        UnityAdsConfigDialog(
            adManager = adManager,
            onDismiss = { showUnityConfig = false }
        )
    }
}

@Composable
private fun ProfileActionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    QuestCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = PrimaryBlue)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = PrimaryText
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = SecondaryText
            )
        }
    }
}
