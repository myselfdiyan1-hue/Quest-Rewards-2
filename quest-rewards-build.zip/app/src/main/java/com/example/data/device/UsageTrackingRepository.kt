package com.example.data.device

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings

class UsageTrackingRepository(private val context: Context) {

    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return if (mode == AppOpsManager.MODE_DEFAULT) {
            // MODE_DEFAULT means "fall back to the manifest permission check"
            context.checkCallingOrSelfPermission(android.Manifest.permission.PACKAGE_USAGE_STATS) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            mode == AppOpsManager.MODE_ALLOWED
        }
    }

    /** Android 13+ blocks "Usage access" for sideloaded apps until "Allow restricted settings" is enabled. */
    fun mayNeedRestrictedSettingsUnlock(): Boolean = Build.VERSION.SDK_INT >= 33

    fun openUsageAccessSettings() {
        val specific = Intent(
            Settings.ACTION_USAGE_ACCESS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        try {
            context.startActivity(specific)
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            } catch (_: Exception) {
                openAppInfoSettings()
            }
        }
    }

    fun openAppInfoSettings() {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            // ignore: no settings activity available
        }
    }

    fun getForegroundUsageSeconds(packageName: String, sinceTimestampMs: Long): Int {
        if (!hasUsageStatsPermission()) return 0
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return 0
        val endTime = System.currentTimeMillis()
        val startTime = maxOf(sinceTimestampMs, endTime - 24 * 60 * 60 * 1000L)
        if (endTime <= startTime) return 0

        val events = usm.queryEvents(startTime, endTime) ?: return 0
        val event = UsageEvents.Event()
        var totalForegroundMs = 0L
        var lastForegroundStartMs: Long? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.packageName == packageName) {
                when (event.eventType) {
                    UsageEvents.Event.ACTIVITY_RESUMED,
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                        if (lastForegroundStartMs == null) {
                            lastForegroundStartMs = event.timeStamp
                        }
                    }
                    UsageEvents.Event.ACTIVITY_PAUSED,
                    UsageEvents.Event.ACTIVITY_STOPPED,
                    UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                        val start = lastForegroundStartMs
                        if (start != null && event.timeStamp >= start) {
                            totalForegroundMs += (event.timeStamp - start)
                            lastForegroundStartMs = null
                        }
                    }
                }
            }
        }

        if (lastForegroundStartMs != null) {
            totalForegroundMs += (endTime - lastForegroundStartMs)
        }

        return (totalForegroundMs / 1000L).toInt().coerceAtLeast(0)
    }
}
