package com.example.ads

import android.content.Context

object UnityAdsConfig {
    const val LEVELPLAY_APP_KEY = "2996e0805"
    const val REWARDED_AD_UNIT_ID = "vb4cp6lrwe6dyfz8"
    const val INTERSTITIAL_AD_UNIT_ID = "0szaxkk9qj7bpc9t"
    const val BANNER_AD_UNIT_ID = "22gfkb6xn9dcb9xm"

    private const val PREFS_NAME = "levelplay_ads_config_prefs"
    private const val KEY_APP_KEY = "levelplay_app_key"
    private const val KEY_REWARDED_ID = "levelplay_rewarded_ad_unit_id"
    private const val KEY_INTERSTITIAL_ID = "levelplay_interstitial_ad_unit_id"
    private const val KEY_BANNER_ID = "levelplay_banner_ad_unit_id"

    fun getEffectiveAppKey(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_APP_KEY, null)?.trim().orEmpty()
        return saved.ifBlank { LEVELPLAY_APP_KEY }
    }

    fun getEffectiveGameId(context: Context): String = getEffectiveAppKey(context)

    fun getEffectiveRewardedId(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_REWARDED_ID, null)?.trim()?.ifBlank { null } ?: REWARDED_AD_UNIT_ID
    }

    fun getEffectiveInterstitialId(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_INTERSTITIAL_ID, null)?.trim()?.ifBlank { null } ?: INTERSTITIAL_AD_UNIT_ID
    }

    fun getEffectiveBannerId(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_BANNER_ID, null)?.trim()?.ifBlank { null } ?: BANNER_AD_UNIT_ID
    }

    fun saveOverrides(
        context: Context,
        appKey: String,
        rewardedId: String,
        interstitialId: String,
        bannerId: String
    ) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_APP_KEY, appKey.trim())
            .putString(KEY_REWARDED_ID, rewardedId.trim())
            .putString(KEY_INTERSTITIAL_ID, interstitialId.trim())
            .putString(KEY_BANNER_ID, bannerId.trim())
            .apply()
    }

    fun isConfigured(context: Context): Boolean {
        return getEffectiveAppKey(context).isNotBlank()
    }
}
