package com.example.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import com.example.BuildConfig
import com.unity3d.mediation.LevelPlay
import com.unity3d.mediation.LevelPlayAdError
import com.unity3d.mediation.LevelPlayAdInfo
import com.unity3d.mediation.LevelPlayConfiguration
import com.unity3d.mediation.LevelPlayInitError
import com.unity3d.mediation.LevelPlayInitListener
import com.unity3d.mediation.LevelPlayInitRequest
import com.unity3d.mediation.interstitial.LevelPlayInterstitialAd
import com.unity3d.mediation.interstitial.LevelPlayInterstitialAdListener
import com.unity3d.mediation.rewarded.LevelPlayReward
import com.unity3d.mediation.rewarded.LevelPlayRewardedAd
import com.unity3d.mediation.rewarded.LevelPlayRewardedAdListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface AdState {
    data object Idle : AdState
    data object Loading : AdState
    data object Ready : AdState
    data object Showing : AdState
    data class Error(val message: String) : AdState
}

class UnityRewardedAdManager(private val appContext: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())

    private val _adState = MutableStateFlow<AdState>(AdState.Idle)
    val adState: StateFlow<AdState> = _adState.asStateFlow()

    private val _isInitializedState = MutableStateFlow(false)
    val isInitializedState: StateFlow<Boolean> = _isInitializedState.asStateFlow()

    private var initInProgress = false
    private var rewardedAd: LevelPlayRewardedAd? = null
    private var interstitialAd: LevelPlayInterstitialAd? = null

    private var rewardedLoading = false
    private var rewardedRetryCount = 0
    private var interstitialLoading = false
    private var interstitialRetryCount = 0

    private var pendingRewardGranted = false
    private var pendingOnRewarded: (() -> Unit)? = null
    private var pendingOnNotCompleted: ((String) -> Unit)? = null
    private var pendingInterstitialOnDone: (() -> Unit)? = null

    private val rewardedRetryRunnable = Runnable { preloadRewardedAd() }
    private val interstitialRetryRunnable = Runnable { preloadInterstitialAd() }

    fun initialize(forceReinit: Boolean = false) {
        val appKey = UnityAdsConfig.getEffectiveAppKey(appContext)
        if (!UnityAdsConfig.isConfigured(appContext)) {
            Log.w(TAG, "LevelPlay App Key is empty.")
            _isInitializedState.value = false
            _adState.value = AdState.Error("LevelPlay App Key not configured")
            return
        }

        if (!forceReinit && (_isInitializedState.value || initInProgress)) {
            if (_isInitializedState.value) {
                preloadRewardedAd()
                preloadInterstitialAd()
            }
            return
        }

        mainHandler.removeCallbacks(rewardedRetryRunnable)
        mainHandler.removeCallbacks(interstitialRetryRunnable)
        rewardedRetryCount = 0
        interstitialRetryCount = 0
        rewardedLoading = false
        interstitialLoading = false
        initInProgress = true
        _isInitializedState.value = false
        _adState.value = AdState.Loading

        try {
            if (BuildConfig.DEBUG) {
                LevelPlay.setAdaptersDebug(true)
                LevelPlay.setMetaData("is_test_suite", "enable")
            }

            val initRequest = LevelPlayInitRequest.Builder(appKey).build()
            LevelPlay.init(
                appContext,
                initRequest,
                object : LevelPlayInitListener {
                    override fun onInitSuccess(configuration: LevelPlayConfiguration) {
                        Log.d(TAG, "LevelPlay initialized successfully with appKey=$appKey")
                        initInProgress = false
                        mainHandler.post {
                            createAdObjects()
                            _isInitializedState.value = true
                            preloadRewardedAd()
                            preloadInterstitialAd()
                        }
                    }

                    override fun onInitFailed(error: LevelPlayInitError) {
                        val msg = formatInitError(error)
                        Log.e(TAG, "LevelPlay init failed: $msg")
                        initInProgress = false
                        _isInitializedState.value = false
                        _adState.value = AdState.Error(msg)
                    }
                }
            )
        } catch (t: Throwable) {
            Log.e(TAG, "Error initializing LevelPlay SDK", t)
            initInProgress = false
            _isInitializedState.value = false
            _adState.value = AdState.Error(t.localizedMessage ?: "LevelPlay initialization failed")
        }
    }

    private fun createAdObjects() {
        val rewardedUnitId = UnityAdsConfig.getEffectiveRewardedId(appContext)
        val interstitialUnitId = UnityAdsConfig.getEffectiveInterstitialId(appContext)

        rewardedAd = LevelPlayRewardedAd(rewardedUnitId).apply {
            setListener(object : LevelPlayRewardedAdListener {
                override fun onAdLoaded(adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Rewarded ad loaded: ${adInfo.adUnitId}")
                    rewardedLoading = false
                    rewardedRetryCount = 0
                    _adState.value = AdState.Ready
                }

                override fun onAdLoadFailed(error: LevelPlayAdError) {
                    val msg = formatAdError(error)
                    Log.w(TAG, "Rewarded ad load failed (${error.adUnitId}): $msg")
                    rewardedLoading = false
                    _adState.value = AdState.Error(msg)
                    scheduleRewardedRetry()
                }

                override fun onAdDisplayed(adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Rewarded ad displayed: ${adInfo.adUnitId}")
                }

                override fun onAdRewarded(reward: LevelPlayReward, adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Rewarded ad reward earned: ${reward.name} x${reward.amount}")
                    pendingRewardGranted = true
                    val rewardCallback = pendingOnRewarded
                    pendingOnRewarded = null
                    mainHandler.post { rewardCallback?.invoke() }
                }

                override fun onAdDisplayFailed(error: LevelPlayAdError, adInfo: LevelPlayAdInfo) {
                    val msg = formatAdError(error)
                    Log.w(TAG, "Rewarded ad display failed: $msg")
                    val notCompletedCallback = pendingOnNotCompleted
                    pendingOnRewarded = null
                    pendingOnNotCompleted = null
                    pendingRewardGranted = false
                    _adState.value = AdState.Error(msg)
                    showToast(msg)
                    mainHandler.post { notCompletedCallback?.invoke(msg) }
                    rewardedRetryCount = 0
                    scheduleRewardedRetry(immediate = true)
                }

                override fun onAdClicked(adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Rewarded ad clicked: ${adInfo.adUnitId}")
                }

                override fun onAdClosed(adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Rewarded ad closed (rewardGranted=$pendingRewardGranted)")
                    val notCompletedCallback = pendingOnNotCompleted
                    val wasRewarded = pendingRewardGranted
                    pendingOnRewarded = null
                    pendingOnNotCompleted = null
                    pendingRewardGranted = false

                    if (!wasRewarded) {
                        val msg = "Ad closed before reward was earned. Watch the full Ad to earn rewards."
                        showToast(msg)
                        mainHandler.post { notCompletedCallback?.invoke(msg) }
                    }
                    rewardedRetryCount = 0
                    preloadRewardedAd()
                }
            })
        }

        interstitialAd = LevelPlayInterstitialAd(interstitialUnitId).apply {
            setListener(object : LevelPlayInterstitialAdListener {
                override fun onAdLoaded(adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Interstitial ad loaded: ${adInfo.adUnitId}")
                    interstitialLoading = false
                    interstitialRetryCount = 0
                }

                override fun onAdLoadFailed(error: LevelPlayAdError) {
                    val msg = formatAdError(error)
                    Log.w(TAG, "Interstitial ad load failed (${error.adUnitId}): $msg")
                    interstitialLoading = false
                    scheduleInterstitialRetry()
                }

                override fun onAdDisplayed(adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Interstitial ad displayed: ${adInfo.adUnitId}")
                }

                override fun onAdDisplayFailed(error: LevelPlayAdError, adInfo: LevelPlayAdInfo) {
                    Log.w(TAG, "Interstitial ad display failed: ${formatAdError(error)}")
                    val done = pendingInterstitialOnDone
                    pendingInterstitialOnDone = null
                    mainHandler.post { done?.invoke() }
                    interstitialRetryCount = 0
                    preloadInterstitialAd()
                }

                override fun onAdClicked(adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Interstitial ad clicked: ${adInfo.adUnitId}")
                }

                override fun onAdClosed(adInfo: LevelPlayAdInfo) {
                    Log.d(TAG, "Interstitial ad closed: ${adInfo.adUnitId}")
                    val done = pendingInterstitialOnDone
                    pendingInterstitialOnDone = null
                    mainHandler.post { done?.invoke() }
                    interstitialRetryCount = 0
                    preloadInterstitialAd()
                }
            })
        }
    }

    fun reinitializeWithConfig(
        gameId: String,
        rewardedId: String,
        interstitialId: String,
        bannerId: String
    ) {
        UnityAdsConfig.saveOverrides(
            context = appContext,
            appKey = gameId,
            rewardedId = rewardedId,
            interstitialId = interstitialId,
            bannerId = bannerId
        )
        initialize(forceReinit = true)
    }

    fun isGameIdConfigured(): Boolean = UnityAdsConfig.isConfigured(appContext)

    fun launchTestSuite(context: Context) {
        if (!_isInitializedState.value) {
            showToast("LevelPlay SDK is still initializing. Please try again in a moment.")
            initialize()
            return
        }
        try {
            var current: Context = context
            while (current !is Activity && current is android.content.ContextWrapper) {
                current = current.baseContext
            }
            LevelPlay.launchTestSuite(current)
        } catch (t: Throwable) {
            val msg = t.localizedMessage ?: "Unable to launch LevelPlay Test Suite"
            Log.e(TAG, msg, t)
            showToast(msg)
        }
    }

    fun preloadRewardedAd() {
        if (!_isInitializedState.value) {
            if (!initInProgress) initialize()
            return
        }
        val ad = rewardedAd ?: run {
            createAdObjects()
            rewardedAd
        } ?: return

        if (ad.isAdReady()) {
            rewardedLoading = false
            _adState.value = AdState.Ready
            return
        }
        if (rewardedLoading) return

        mainHandler.removeCallbacks(rewardedRetryRunnable)
        rewardedLoading = true
        _adState.value = AdState.Loading
        ad.loadAd()
    }

    fun showRewardedAd(
        activity: Activity,
        onRewarded: () -> Unit,
        onNotCompleted: (String) -> Unit = {},
        onNeedsGameIdConfig: () -> Unit = {}
    ) {
        if (!UnityAdsConfig.isConfigured(appContext)) {
            onNeedsGameIdConfig()
            return
        }

        if (!_isInitializedState.value) {
            showToast("Initializing LevelPlay SDK...")
            initialize()
            return
        }

        val ad = rewardedAd
        if (ad == null || !ad.isAdReady()) {
            showToast("Loading Ad...")
            rewardedRetryCount = 0
            preloadRewardedAd()
            return
        }

        pendingRewardGranted = false
        pendingOnRewarded = onRewarded
        pendingOnNotCompleted = onNotCompleted
        _adState.value = AdState.Showing
        ad.showAd(activity)
    }

    fun preloadInterstitialAd() {
        if (!_isInitializedState.value) return
        val ad = interstitialAd ?: return
        if (ad.isAdReady() || interstitialLoading) return

        mainHandler.removeCallbacks(interstitialRetryRunnable)
        interstitialLoading = true
        ad.loadAd()
    }

    fun showInterstitialIfReady(activity: Activity, onDone: () -> Unit = {}) {
        val ad = interstitialAd
        if (!_isInitializedState.value || ad == null || !ad.isAdReady()) {
            preloadInterstitialAd()
            onDone()
            return
        }
        pendingInterstitialOnDone = onDone
        ad.showAd(activity)
    }

    private fun scheduleRewardedRetry(immediate: Boolean = false) {
        if (rewardedRetryCount >= MAX_RETRIES) return
        rewardedRetryCount++
        val delayMs = if (immediate) 1500L else RETRY_BASE_DELAY_MS * rewardedRetryCount
        mainHandler.removeCallbacks(rewardedRetryRunnable)
        mainHandler.postDelayed(rewardedRetryRunnable, delayMs)
    }

    private fun scheduleInterstitialRetry() {
        if (interstitialRetryCount >= MAX_RETRIES) return
        interstitialRetryCount++
        val delayMs = RETRY_BASE_DELAY_MS * interstitialRetryCount
        mainHandler.removeCallbacks(interstitialRetryRunnable)
        mainHandler.postDelayed(interstitialRetryRunnable, delayMs)
    }

    private fun formatInitError(error: LevelPlayInitError): String {
        val msg = error.errorMessage.trim()
        return if (msg.isNotEmpty()) {
            "$msg (Code ${error.errorCode})"
        } else {
            "LevelPlay init error (${error.errorCode})"
        }
    }

    private fun formatAdError(error: LevelPlayAdError): String {
        val msg = error.errorMessage.trim()
        return if (msg.isNotEmpty()) {
            "$msg (Code ${error.errorCode})"
        } else {
            "LevelPlay ad error (${error.errorCode})"
        }
    }

    private fun showToast(message: String) {
        mainHandler.post {
            Toast.makeText(appContext, message, Toast.LENGTH_SHORT).show()
        }
    }

    private companion object {
        const val TAG = "UnityRewardedAdManager"
        const val MAX_RETRIES = 4
        const val RETRY_BASE_DELAY_MS = 5000L
    }
}
