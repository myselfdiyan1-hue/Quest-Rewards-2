package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.config.TestConfig
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class GameObjectType(val displayName: String) {
    APPLE("Apple"),
    CAR("Car"),
    BANANA("Banana"),
    DOG("Dog"),
    FOOTBALL("Football"),
    CAT("Cat"),
    PARROT("Parrot"),
    BICYCLE("Bicycle"),
    TREE("Tree")
}

data class ImageFinderUiState(
    val level: Int = 1,
    val findsCount: Int = 0,
    val target: GameObjectType = GameObjectType.APPLE,
    val options: List<GameObjectType> = emptyList(),
    val timeLeftSeconds: Int = 30,
    val feedbackMessage: String? = null,
    val isErrorFeedback: Boolean = false,
    val isAdvancing: Boolean = false,
    val isPaused: Boolean = false,
    val isGameOver: Boolean = false,
    val isRoundComplete: Boolean = false,
    val gemCollected: Boolean = false,
    val roundId: String = UUID.randomUUID().toString()
)

class ImageFinderViewModel(
    private val rewardRepository: RewardRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ImageFinderUiState())
    val uiState: StateFlow<ImageFinderUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var transitionJob: Job? = null

    init {
        startNewCycle()
    }

    fun startNewCycle() {
        timerJob?.cancel()
        transitionJob?.cancel()
        val (target, options) = generatePuzzle()
        _uiState.value = ImageFinderUiState(
            level = 1,
            findsCount = 0,
            target = target,
            options = options,
            timeLeftSeconds = 30,
            roundId = UUID.randomUUID().toString()
        )
        startTimer()
    }

    private fun generatePuzzle(previousTarget: GameObjectType? = null): Pair<GameObjectType, List<GameObjectType>> {
        val all = GameObjectType.entries.toList()
        val target = all.filter { it != previousTarget }.random()
        val distractors = all.filter { it != target }.shuffled().take(5)
        val options = (distractors + target).shuffled()
        return target to options
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val state = _uiState.value
                if (state.isPaused || state.isGameOver || state.isRoundComplete || state.isAdvancing) {
                    continue
                }
                val next = state.timeLeftSeconds - 1
                if (next <= 0) {
                    _uiState.value = state.copy(
                        timeLeftSeconds = 0,
                        isGameOver = true,
                        feedbackMessage = "Time's up! Try again.",
                        isErrorFeedback = true
                    )
                    break
                } else {
                    _uiState.value = state.copy(timeLeftSeconds = next)
                }
            }
        }
    }

    fun onOptionTapped(selected: GameObjectType) {
        val state = _uiState.value
        if (state.isPaused || state.isGameOver || state.isRoundComplete || state.isAdvancing) return

        if (selected == state.target) {
            val newFinds = state.findsCount + 1
            if (newFinds >= 3) {
                timerJob?.cancel()
                _uiState.value = state.copy(
                    findsCount = 3,
                    feedbackMessage = "Correct! (3/3 found) Keep going! 🔥",
                    isErrorFeedback = false,
                    isAdvancing = true
                )
                transitionJob = viewModelScope.launch {
                    delay(1000L)
                    _uiState.value = _uiState.value.copy(
                        isAdvancing = false,
                        isRoundComplete = true,
                        feedbackMessage = null
                    )
                }
            } else {
                _uiState.value = state.copy(
                    findsCount = newFinds,
                    feedbackMessage = "Correct! ($newFinds/3 found) Keep going! 🔥",
                    isErrorFeedback = false,
                    isAdvancing = true
                )
                transitionJob = viewModelScope.launch {
                    delay(1200L)
                    val (nextTarget, nextOptions) = generatePuzzle(state.target)
                    _uiState.value = _uiState.value.copy(
                        level = state.level + 1,
                        target = nextTarget,
                        options = nextOptions,
                        timeLeftSeconds = 30,
                        feedbackMessage = null,
                        isErrorFeedback = false,
                        isAdvancing = false
                    )
                }
            }
        } else {
            _uiState.value = state.copy(
                feedbackMessage = "Oops! That's a ${selected.displayName}. Find the ${state.target.displayName}!",
                isErrorFeedback = true
            )
        }
    }

    fun togglePause() {
        val state = _uiState.value
        if (state.isGameOver || state.isRoundComplete) return
        _uiState.value = state.copy(isPaused = !state.isPaused)
    }

    fun onRewardedAdCompleted(gemReward: Int = TestConfig.GEM_REWARD_PER_ROUND) {
        val roundId = _uiState.value.roundId
        viewModelScope.launch {
            rewardRepository.awardGameRoundGem(roundId, gemReward)
            _uiState.value = _uiState.value.copy(gemCollected = true)
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        transitionJob?.cancel()
    }
}
