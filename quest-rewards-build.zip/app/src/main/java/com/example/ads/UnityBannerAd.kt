package com.example.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.GemQuestApplication
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SurfaceVariant
import com.unity3d.mediation.LevelPlayAdError
import com.unity3d.mediation.LevelPlayAdInfo
import com.unity3d.mediation.LevelPlayAdSize
import com.unity3d.mediation.banner.LevelPlayBannerAdView
import com.unity3d.mediation.banner.LevelPlayBannerAdViewListener

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun UnityBannerAd(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val adManager = remember(context) {
        (context.applicationContext as GemQuestApplication).unityRewardedAdManager
    }
    val isInitialized by adManager.isInitializedState.collectAsStateWithLifecycle()
    var isLoaded by remember { mutableStateOf(false) }

    if (activity == null) return

    if (!isInitialized) {
        val isConfigured = UnityAdsConfig.isConfigured(context)
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(54.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceVariant)
                .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (isConfigured) "Initializing LevelPlay Banner Ad..." else "LevelPlay Banner Ad (Configure App Key in Profile)",
                style = MaterialTheme.typography.labelSmall,
                color = SecondaryText
            )
        }
        return
    }

    val bannerAdUnitId = remember(isInitialized) { UnityAdsConfig.getEffectiveBannerId(context) }
    val bannerView = remember(activity, bannerAdUnitId) {
        val adConfig = LevelPlayBannerAdView.Config.Builder()
            .setAdSize(LevelPlayAdSize.BANNER)
            .build()
        LevelPlayBannerAdView(activity, bannerAdUnitId, adConfig).apply {
            setBannerListener(object : LevelPlayBannerAdViewListener {
                override fun onAdLoaded(adInfo: LevelPlayAdInfo) {
                    isLoaded = true
                }

                override fun onAdLoadFailed(error: LevelPlayAdError) {
                    Log.w("UnityBannerAd", "Banner load failed: ${error.errorMessage} (${error.errorCode})")
                    isLoaded = false
                }

                override fun onAdDisplayed(adInfo: LevelPlayAdInfo) {}
                override fun onAdDisplayFailed(adInfo: LevelPlayAdInfo, error: LevelPlayAdError) {
                    isLoaded = false
                }

                override fun onAdClicked(adInfo: LevelPlayAdInfo) {}
                override fun onAdCollapsed(adInfo: LevelPlayAdInfo) {}
                override fun onAdExpanded(adInfo: LevelPlayAdInfo) {}
            })
            loadAd()
        }
    }

    DisposableEffect(bannerView) {
        onDispose {
            bannerView.destroy()
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceVariant)
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (!isLoaded) {
            Text(
                text = "Loading LevelPlay Banner Ad...",
                style = MaterialTheme.typography.labelSmall,
                color = SecondaryText
            )
        }
        AndroidView(
            factory = { bannerView },
            modifier = Modifier.fillMaxWidth()
        )
    }
}
