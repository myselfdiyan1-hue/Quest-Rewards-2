package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class QuestTypeConverters {
    @TypeConverter
    fun fromOfferStatus(status: OfferStatus): String = status.name

    @TypeConverter
    fun toOfferStatus(value: String): OfferStatus =
        runCatching { OfferStatus.valueOf(value) }.getOrDefault(OfferStatus.NOT_STARTED)
}

@Database(
    entities = [
        UserBalanceEntity::class,
        GameRoundEntity::class,
        OfferSessionEntity::class,
        TransactionEntity::class,
        CompletedTaskEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(QuestTypeConverters::class)
abstract class QuestDatabase : RoomDatabase() {
    abstract fun questDao(): QuestDao

    companion object {
        @Volatile
        private var INSTANCE: QuestDatabase? = null

        fun getInstance(context: Context): QuestDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    QuestDatabase::class.java,
                    "quest_rewards_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
