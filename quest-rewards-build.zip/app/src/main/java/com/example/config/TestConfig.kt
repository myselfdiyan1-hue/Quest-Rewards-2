package com.example.config

object TestConfig {
    const val SUPER_OFFER_REQUIRED_GEMS = 2
    const val SUPER_OFFER_COIN_REWARD = 10
    const val REQUIRED_USAGE_SECONDS = 120
    const val GEM_REWARD_PER_ROUND = 1
    const val INITIAL_COINS = 0
    const val INITIAL_GEMS = 0
    const val WELCOME_BONUS_COINS = 50
    const val WELCOME_BONUS_GEMS = 5
}
