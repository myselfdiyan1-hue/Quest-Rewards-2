# APK build korar 2 ta way

## Way 1: Android Studio (PC)
1. Zip extract kore Android Studio te "Open" koro, Gradle sync hote dao.
2. Build > Build Bundle(s) / APK(s) > Build APK(s)
3. APK: app/build/outputs/apk/debug/app-debug.apk

## Way 2: GitHub (phone theke, PC lagbe na)
1. github.com e notun repository banao, ei project er shob file upload koro
   (.github folder shoho).
2. Repo > Actions > "Build APK" > Run workflow
3. 5-10 minute por run er shesh e "Artifacts" theke quest-rewards-debug-apk download koro.
