package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.config.TestConfig
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class FirebaseManager(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        auth = Firebase.auth
    )

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    fun authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun currentDailyKey(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)
    }

    fun currentWeeklyKey(): String {
        val cal = Calendar.getInstance(Locale.US)
        val year = cal.get(Calendar.YEAR)
        val week = cal.get(Calendar.WEEK_OF_YEAR)
        return String.format(Locale.US, "%04d-W%02d", year, week)
    }

    suspend fun ensureUserDocument(user: FirebaseUser, config: AppConfig): UserProfile {
        val uid = user.uid
        val userRef = db.collection("users").document(uid)
        val today = currentDailyKey()
        val week = currentWeeklyKey()

        return try {
            val snapshot = userRef.get().await()
            if (!snapshot.exists()) {
                val initialCoins = config.welcomeBonusCoins.takeIf { it > 0 } ?: TestConfig.WELCOME_BONUS_COINS
                val initialGems = config.welcomeBonusGems.takeIf { it >= 0 } ?: TestConfig.WELCOME_BONUS_GEMS
                val displayName = user.displayName?.takeIf { it.isNotBlank() } ?: "Quest Player"
                val email = user.email ?: ""
                val photoUrl = user.photoUrl?.toString()

                val payload = mutableMapOf<String, Any>(
                    "uid" to uid,
                    "displayName" to displayName,
                    "email" to email,
                    "coins" to initialCoins,
                    "gems" to initialGems,
                    "dailyCoins" to initialCoins,
                    "weeklyCoins" to initialCoins,
                    "lastDailyDate" to today,
                    "lastWeeklyDate" to week,
                    "isBlocked" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (photoUrl != null) {
                    payload["photoUrl"] = photoUrl
                }
                userRef.set(payload).await()
                syncLeaderboardEntry(
                    uid = uid,
                    displayName = displayName,
                    photoUrl = photoUrl,
                    dailyCoins = initialCoins,
                    weeklyCoins = initialCoins,
                    lastDailyDate = today,
                    lastWeeklyDate = week
                )
                UserProfile(
                    id = uid,
                    uid = uid,
                    displayName = displayName,
                    email = email,
                    photoUrl = photoUrl,
                    coins = initialCoins,
                    gems = initialGems,
                    dailyCoins = initialCoins,
                    weeklyCoins = initialCoins,
                    lastDailyDate = today,
                    lastWeeklyDate = week,
                    isBlocked = false
                )
            } else {
                val existing = snapshot.toObject(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserProfile(id = uid, uid = uid)

                val resetDaily = existing.lastDailyDate != today
                val resetWeekly = existing.lastWeeklyDate != week
                val resolvedDaily = if (resetDaily) 0 else existing.dailyCoins
                val resolvedWeekly = if (resetWeekly) 0 else existing.weeklyCoins

                if ((resetDaily || resetWeekly) && !existing.isBlocked) {
                    val updates = mapOf(
                        "dailyCoins" to resolvedDaily,
                        "weeklyCoins" to resolvedWeekly,
                        "lastDailyDate" to today,
                        "lastWeeklyDate" to week,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    userRef.update(updates).await()
                    syncLeaderboardEntry(
                        uid = uid,
                        displayName = existing.displayName,
                        photoUrl = existing.photoUrl,
                        dailyCoins = resolvedDaily,
                        weeklyCoins = resolvedWeekly,
                        lastDailyDate = today,
                        lastWeeklyDate = week
                    )
                }
                existing.copy(
                    dailyCoins = resolvedDaily,
                    weeklyCoins = resolvedWeekly,
                    lastDailyDate = today,
                    lastWeeklyDate = week
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userRef.path)
            UserProfile(
                id = uid,
                uid = uid,
                displayName = user.displayName ?: "Quest Player",
                email = user.email ?: "",
                photoUrl = user.photoUrl?.toString(),
                coins = TestConfig.WELCOME_BONUS_COINS,
                gems = TestConfig.WELCOME_BONUS_GEMS,
                dailyCoins = TestConfig.WELCOME_BONUS_COINS,
                weeklyCoins = TestConfig.WELCOME_BONUS_COINS,
                lastDailyDate = today,
                lastWeeklyDate = week
            )
        }
    }

    fun observeUserProfile(uid: String): Flow<UserProfile?> = flow {
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    handleFlowError(error, OperationType.GET, path, uid)
                    emit(null)
                }
        )
    }

    fun observeAppConfig(): Flow<AppConfig> = flow {
        val path = "app_config"
        emitAll(
            db.collection(path).limit(1)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.firstOrNull()?.toObject(
                        AppConfig::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: AppConfig()
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, auth.currentUser?.uid)
                    emit(AppConfig())
                }
        )
    }

    fun observePayoutMethods(): Flow<List<PayoutMethod>> = flow {
        val path = "payout_methods"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    val items = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(PayoutMethod::class.java)
                    }.filter { it.isEnabled }
                    items.ifEmpty { BuiltInPayoutMethods.defaults }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, auth.currentUser?.uid)
                    emit(BuiltInPayoutMethods.defaults)
                }
        )
    }

    fun observeTasks(): Flow<List<TaskItem>> = flow {
        val path = "tasks"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(TaskItem::class.java)
                    }.filter { it.isEnabled }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, auth.currentUser?.uid)
                    emit(emptyList())
                }
        )
    }

    fun observeTaskCategories(): Flow<List<TaskCategory>> = flow {
        val path = "task_categories"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(TaskCategory::class.java)
                    }.filter { it.isEnabled }.sortedBy { it.order }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, auth.currentUser?.uid)
                    emit(emptyList())
                }
        )
    }

    fun observeLeaderboard(): Flow<List<LeaderboardEntry>> = flow {
        val path = "leaderboard"
        val today = currentDailyKey()
        val week = currentWeeklyKey()
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(LeaderboardEntry::class.java)?.let { entry ->
                            entry.copy(
                                dailyCoins = if (entry.lastDailyDate == today) entry.dailyCoins else 0,
                                weeklyCoins = if (entry.lastWeeklyDate == week) entry.weeklyCoins else 0
                            )
                        }
                    }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, auth.currentUser?.uid)
                    emit(emptyList())
                }
        )
    }

    fun observeWithdrawals(uid: String): Flow<List<WithdrawalRecord>> = flow {
        val path = "withdrawals"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        WithdrawalRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    emit(emptyList())
                }
        )
    }

    suspend fun syncBalance(coins: Int, gems: Int, earnedCoinsDelta: Int = 0) {
        val user = auth.currentUser ?: return
        val uid = user.uid
        val userRef = db.collection("users").document(uid)
        val today = currentDailyKey()
        val week = currentWeeklyKey()

        try {
            val snap = userRef.get().await()
            if (!snap.exists()) {
                ensureUserDocument(user, AppConfig())
            }
            val current = snap.toObject(UserProfile::class.java)
            if (current?.isBlocked == true) return

            val currentDaily = if (current?.lastDailyDate == today) current.dailyCoins else 0
            val currentWeekly = if (current?.lastWeeklyDate == week) current.weeklyCoins else 0
            val newDaily = currentDaily + earnedCoinsDelta.coerceAtLeast(0)
            val newWeekly = currentWeekly + earnedCoinsDelta.coerceAtLeast(0)

            val updates = mapOf(
                "coins" to coins.coerceAtLeast(0),
                "gems" to gems.coerceAtLeast(0),
                "dailyCoins" to newDaily,
                "weeklyCoins" to newWeekly,
                "lastDailyDate" to today,
                "lastWeeklyDate" to week,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            userRef.update(updates).await()

            syncLeaderboardEntry(
                uid = uid,
                displayName = current?.displayName ?: user.displayName ?: "Quest Player",
                photoUrl = current?.photoUrl ?: user.photoUrl?.toString(),
                dailyCoins = newDaily,
                weeklyCoins = newWeekly,
                lastDailyDate = today,
                lastWeeklyDate = week
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path)
        }
    }

    private suspend fun syncLeaderboardEntry(
        uid: String,
        displayName: String,
        photoUrl: String?,
        dailyCoins: Int,
        weeklyCoins: Int,
        lastDailyDate: String,
        lastWeeklyDate: String
    ) {
        val ref = db.collection("leaderboard").document(uid)
        val payload = mutableMapOf<String, Any>(
            "uid" to uid,
            "displayName" to displayName.ifBlank { "Quest Player" },
            "dailyCoins" to dailyCoins.coerceAtLeast(0),
            "weeklyCoins" to weeklyCoins.coerceAtLeast(0),
            "lastDailyDate" to lastDailyDate,
            "lastWeeklyDate" to lastWeeklyDate,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (photoUrl != null) {
            payload["photoUrl"] = photoUrl
        }
        try {
            ref.set(payload, SetOptions.merge()).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, ref.path)
        }
    }

    suspend fun createWithdrawal(
        method: PayoutMethod,
        accountDetail: String,
        coinsDeducted: Int,
        cashAmount: Double
    ): Result<String> {
        val user = auth.currentUser
            ?: return Result.failure(IllegalStateException("Please sign in with Google first."))
        val uid = user.uid
        val docRef = db.collection("withdrawals").document()
        val payload = mapOf(
            "userId" to uid,
            "userName" to (user.displayName ?: "Quest Player"),
            "userEmail" to (user.email ?: ""),
            "payoutMethodId" to method.id,
            "payoutMethodName" to method.name,
            "accountDetail" to accountDetail.trim(),
            "coinsDeducted" to coinsDeducted,
            "cashAmount" to cashAmount,
            "status" to "pending",
            "createdAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun recordCompletedTask(taskId: String, rewardCoins: Int) {
        val uid = auth.currentUser?.uid ?: return
        val docRef = db.collection("users").document(uid)
            .collection("completed_tasks").document(taskId)
        val payload = mapOf(
            "taskId" to taskId,
            "rewardCoins" to rewardCoins,
            "completedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
        }
    }

    suspend fun recordRemoteTransaction(
        title: String,
        type: String,
        coinsDelta: Int,
        gemsDelta: Int,
        status: String = "Success"
    ) {
        val uid = auth.currentUser?.uid ?: return
        val docRef = db.collection("users").document(uid)
            .collection("transactions").document()
        val payload = mapOf(
            "title" to title,
            "type" to type,
            "coinsDelta" to coinsDelta,
            "gemsDelta" to gemsDelta,
            "status" to status,
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
        }
    }

    private fun handleFlowError(
        error: Throwable,
        op: OperationType,
        path: String,
        uid: String?
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val toLog = firestoreError ?: (error as? Exception)
        if (toLog != null && (uid == null || auth.currentUser?.uid == uid)) {
            handleFirestoreError(toLog, op, path)
        }
    }
}
