package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val QuestLightColorScheme = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    primaryContainer = Lavender,
    onPrimaryContainer = PrimaryText,
    secondary = SecondaryBlue,
    onSecondary = Color.White,
    secondaryContainer = SurfaceVariant,
    onSecondaryContainer = PrimaryText,
    tertiary = PurpleAccent,
    onTertiary = Color.White,
    background = MainBackground,
    onBackground = PrimaryText,
    surface = CardWhite,
    onSurface = PrimaryText,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = SecondaryText,
    outline = BorderSubtle,
    error = ErrorRed,
    onError = Color.White
)

val QuestShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun QuestRewardsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = QuestLightColorScheme,
        typography = QuestTypography,
        shapes = QuestShapes,
        content = content
    )
}
