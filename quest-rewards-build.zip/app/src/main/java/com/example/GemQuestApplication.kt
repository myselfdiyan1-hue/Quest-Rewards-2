package com.example

import android.app.Application
import com.example.ads.UnityRewardedAdManager
import com.example.data.device.InstallationDetectionRepository
import com.example.data.device.UsageTrackingRepository
import com.example.data.local.QuestDatabase
import com.example.data.remote.FirebaseManager
import com.example.data.repository.RewardRepository
import com.google.firebase.FirebaseApp

class GemQuestApplication : Application() {

    val database: QuestDatabase by lazy { QuestDatabase.getInstance(this) }
    val firebaseManager: FirebaseManager by lazy {
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseApp.initializeApp(this)
        }
        FirebaseManager(this)
    }
    val rewardRepository: RewardRepository by lazy {
        RewardRepository(database.questDao(), firebaseManager)
    }
    lateinit var unityRewardedAdManager: UnityRewardedAdManager
        private set
    val installationRepository: InstallationDetectionRepository by lazy {
        InstallationDetectionRepository(this)
    }
    val usageTrackingRepository: UsageTrackingRepository by lazy {
        UsageTrackingRepository(this)
    }

    override fun onCreate() {
        super.onCreate()
        unityRewardedAdManager = UnityRewardedAdManager(this).also {
            it.initialize()
        }
    }
}
