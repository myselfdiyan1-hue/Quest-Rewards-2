package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.config.TestConfig

enum class OfferStatus {
    NOT_STARTED,
    IN_PROGRESS,
    PENDING_VERIFICATION,
    COMPLETED,
    REJECTED
}

@Entity(tableName = "user_balance")
data class UserBalanceEntity(
    @PrimaryKey val id: Int = 1,
    val coins: Int = TestConfig.INITIAL_COINS,
    val gems: Int = TestConfig.INITIAL_GEMS
)

@Entity(tableName = "game_rounds")
data class GameRoundEntity(
    @PrimaryKey val roundId: String,
    val gemsAwarded: Int,
    val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "offer_sessions")
data class OfferSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val status: OfferStatus = OfferStatus.NOT_STARTED,
    val targetPackage: String? = null,
    val targetAppName: String? = null,
    val observedUsageSeconds: Int = 0,
    val requiredUsageSeconds: Int = TestConfig.REQUIRED_USAGE_SECONDS,
    val adWatched: Boolean = false,
    val coinsRewarded: Boolean = false,
    val initialPackagesSnapshot: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val type: String, // EARN, WITHDRAW, UNLOCK
    val coinsDelta: Int,
    val gemsDelta: Int = 0,
    val status: String = "Success",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "completed_tasks")
data class CompletedTaskEntity(
    @PrimaryKey val taskId: String,
    val title: String,
    val rewardCoins: Int,
    val completedAt: Long = System.currentTimeMillis()
)
