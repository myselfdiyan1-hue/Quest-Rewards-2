package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.UnityBannerAd
import com.example.data.remote.TaskItem
import com.example.ui.components.CoinBadge
import com.example.ui.components.QuestCard
import com.example.ui.theme.CardWhite
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceVariant
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksScreen(
    mainViewModel: MainViewModel,
    onOpenSuperOffer: () -> Unit
) {
    val context = LocalContext.current
    val balance by mainViewModel.balance.collectAsStateWithLifecycle()
    val tasks by mainViewModel.tasks.collectAsStateWithLifecycle()
    val categories by mainViewModel.taskCategories.collectAsStateWithLifecycle()
    val completedIds by mainViewModel.completedTaskIds.collectAsStateWithLifecycle()
    val appConfig by mainViewModel.appConfig.collectAsStateWithLifecycle()
    val actionMessage by mainViewModel.actionMessage.collectAsStateWithLifecycle()

    val categoryNames = remember(categories, tasks) {
        val fromRemote = categories.map { it.name }.filter { it.isNotBlank() }
        val fromTasks = tasks.map { it.category }.filter { it.isNotBlank() }
        listOf("All") + (fromRemote + fromTasks).distinct()
    }
    var selectedCategory by remember { mutableStateOf("All") }
    var activeTask by remember { mutableStateOf<TaskItem?>(null) }

    val filteredTasks = remember(tasks, selectedCategory) {
        if (selectedCategory == "All") tasks else tasks.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
    ) {
        Surface(color = HeaderBackground, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Tasks",
                        style = MaterialTheme.typography.headlineMedium,
                        color = PrimaryText
                    )
                    Text(
                        text = "Complete missions to earn real coins",
                        style = MaterialTheme.typography.bodySmall,
                        color = SecondaryText
                    )
                }
                CoinBadge(amountText = "${balance.coins}")
            }
        }

        actionMessage?.let { msg ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                color = SuccessGreen.copy(alpha = 0.14f)
            ) {
                Text(
                    text = msg,
                    style = MaterialTheme.typography.bodySmall,
                    color = SuccessGreen,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // First Card: SUPER OFFER
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(PrimaryBlue, PurpleAccent)))
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = OrangeAccent
                            ) {
                                Text(
                                    text = "HIGH REWARD",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            CoinBadge(amountText = "+${appConfig.superOfferUnlockCoins} Coins")
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = "SUPER OFFER",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Earn +${appConfig.superOfferUnlockCoins} Coins per completion",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = onOpenSuperOffer,
                            modifier = Modifier.testTag("tasks_super_offer_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CardWhite,
                                contentColor = PrimaryBlue
                            )
                        ) {
                            Icon(Icons.Filled.RocketLaunch, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Open Super Offer", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Category chips
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categoryNames) { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            if (filteredTasks.isEmpty()) {
                item {
                    QuestCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Assignment,
                                contentDescription = null,
                                tint = SecondaryText,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(
                                text = "No Tasks Available",
                                style = MaterialTheme.typography.titleMedium,
                                color = PrimaryText,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(filteredTasks, key = { it.id }) { task ->
                    val isDone = completedIds.contains(task.id)
                    val isSurvey = task.category.contains("survey", ignoreCase = true)
                    QuestCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("task_card_${task.id}"),
                        onClick = { activeTask = task }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = PrimaryBlue.copy(alpha = 0.1f)
                                ) {
                                    Icon(
                                        imageVector = if (isSurvey) Icons.Filled.Quiz else Icons.Filled.Assignment,
                                        contentDescription = null,
                                        tint = PrimaryBlue,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = task.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = PrimaryText
                                    )
                                    Text(
                                        text = task.category,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SecondaryText
                                    )
                                }
                            }
                            if (isDone) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = SuccessGreen.copy(alpha = 0.14f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = "Done",
                                            tint = SuccessGreen,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            text = "Done",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = SuccessGreen
                                        )
                                    }
                                }
                            } else {
                                CoinBadge(amountText = "+${task.rewardCoins}")
                            }
                        }
                    }
                }
            }
        }

        // Bottom Unity Banner Ad
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            UnityBannerAd()
        }
    }

    activeTask?.let { task ->
        val isDone = completedIds.contains(task.id)
        val isSurvey = task.category.contains("survey", ignoreCase = true)
        ModalBottomSheet(
            onDismissRequest = { activeTask = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = CardWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = PrimaryText,
                        modifier = Modifier.weight(1f)
                    )
                    CoinBadge(amountText = "+${task.rewardCoins} Coins")
                }

                if (task.description.isNotBlank()) {
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = SecondaryText
                    )
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Instructions:",
                            style = MaterialTheme.typography.titleSmall,
                            color = PrimaryText
                        )
                        Text("1. Tap Open Task Link / App below to open the mission.", style = MaterialTheme.typography.bodySmall, color = SecondaryText)
                        Text("2. Follow the mission steps carefully on the destination page.", style = MaterialTheme.typography.bodySmall, color = SecondaryText)
                        Text("3. Return here and tap Claim to receive +${task.rewardCoins} Coins.", style = MaterialTheme.typography.bodySmall, color = SecondaryText)
                    }
                }

                if (task.actionUrl.isNotBlank()) {
                    OutlinedButton(
                        onClick = {
                            runCatching {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(task.actionUrl))
                                context.startActivity(intent)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Open Task Link / App")
                    }
                }

                Button(
                    onClick = {
                        mainViewModel.completeTask(task)
                        activeTask = null
                    },
                    enabled = !isDone,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isDone) SuccessGreen else PrimaryBlue
                    )
                ) {
                    Text(
                        text = when {
                            isDone -> "Done"
                            isSurvey -> "Submit & Claim +${task.rewardCoins} Coins"
                            else -> "Complete & Claim +${task.rewardCoins} Coins"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}
