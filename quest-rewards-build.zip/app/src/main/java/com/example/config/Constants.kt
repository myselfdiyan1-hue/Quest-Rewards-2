package com.example.config

object Constants {
    const val APP_NAME = "Quest Rewards"
    const val PACKAGE_NAME = "com.questrewards"
    const val UNITY_GAME_ID = "800438571"
    const val REWARDED_PLACEMENT_ID = "Rewarded_Android"
    const val INTERSTITIAL_PLACEMENT_ID = "Interstitial_Android"
    const val TEST_MODE = false
    const val ESTIMATED_ECPM_USD = 2.0
}
