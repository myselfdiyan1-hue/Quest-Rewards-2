package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.remote.LeaderboardEntry
import com.example.ui.components.CoinBadge
import com.example.ui.components.InitialsAvatar
import com.example.ui.components.QuestCard
import com.example.ui.theme.CoinGold
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SecondaryText
import com.example.ui.viewmodel.MainViewModel

@Composable
fun LeaderboardScreen(
    mainViewModel: MainViewModel,
    currentUserId: String
) {
    val entries by mainViewModel.leaderboard.collectAsStateWithLifecycle()
    val userProfile by mainViewModel.userProfile.collectAsStateWithLifecycle()
    val isLoading by mainViewModel.isLeaderboardLoading.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Daily, 1 = Weekly
    val isDaily = selectedTab == 0
    val tabName = if (isDaily) "Daily" else "Weekly"

    val mergedEntries = remember(entries, userProfile, isDaily) {
        val list = entries.toMutableList()
        val me = userProfile
        if (me != null && list.none { it.uid == currentUserId }) {
            list.add(
                LeaderboardEntry(
                    id = me.uid,
                    uid = me.uid,
                    displayName = me.displayName.ifBlank { "You" },
                    photoUrl = me.photoUrl,
                    dailyCoins = me.dailyCoins,
                    weeklyCoins = me.weeklyCoins,
                    lastDailyDate = me.lastDailyDate,
                    lastWeeklyDate = me.lastWeeklyDate
                )
            )
        }
        if (isDaily) {
            list.sortedByDescending { it.dailyCoins }
        } else {
            list.sortedByDescending { it.weeklyCoins }
        }
    }

    val myIndex = mergedEntries.indexOfFirst { it.uid == currentUserId }
    val myRankText = if (myIndex >= 0) "#${myIndex + 1}" else "-"
    val myEntry = mergedEntries.getOrNull(myIndex)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
    ) {
        Surface(color = HeaderBackground, shadowElevation = 4.dp) {
            Column(modifier = Modifier.statusBarsPadding()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.EmojiEvents,
                        contentDescription = null,
                        tint = CoinGold,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Earning Leaderboard",
                        style = MaterialTheme.typography.headlineMedium,
                        color = PrimaryText
                    )
                }

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = HeaderBackground,
                    contentColor = PrimaryBlue
                ) {
                    Tab(
                        selected = isDaily,
                        onClick = { selectedTab = 0 },
                        text = { Text("Daily") },
                        modifier = Modifier.testTag("leaderboard_tab_daily")
                    )
                    Tab(
                        selected = !isDaily,
                        onClick = { selectedTab = 1 },
                        text = { Text("Weekly") },
                        modifier = Modifier.testTag("leaderboard_tab_weekly")
                    )
                }
            }
        }

        if (isLoading && mergedEntries.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = PrimaryBlue)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = if (isDaily) "Loading daily earnings..." else "Loading weekly earnings...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SecondaryText
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Top 3 Podium
                if (mergedEntries.isNotEmpty()) {
                    item {
                        PodiumSection(
                            topThree = mergedEntries.take(3),
                            isDaily = isDaily
                        )
                    }
                }

                // Remaining Ranked List
                val rest = if (mergedEntries.size > 3) mergedEntries.drop(3) else emptyList()
                itemsIndexed(rest, key = { _, item -> item.uid }) { idx, entry ->
                    val rank = idx + 4
                    val coins = if (isDaily) entry.dailyCoins else entry.weeklyCoins
                    QuestCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "#$rank",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PrimaryBlue,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(36.dp)
                                )
                                InitialsAvatar(name = entry.displayName, size = 40.dp)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = entry.displayName + if (entry.uid == currentUserId) " (You)" else "",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = PrimaryText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Today: +${entry.dailyCoins} Coins • Weekly: +${entry.weeklyCoins} Coins",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SecondaryText
                                    )
                                }
                            }
                            CoinBadge(amountText = "+$coins")
                        }
                    }
                }
            }
        }

        // Pinned Current User Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(PrimaryBlue, PurpleAccent)))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${userProfile?.displayName ?: myEntry?.displayName ?: "Player"} (You)",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Today's Earning: +${myEntry?.dailyCoins ?: userProfile?.dailyCoins ?: 0} • Weekly Earning: +${myEntry?.weeklyCoins ?: userProfile?.weeklyCoins ?: 0}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$tabName Rank",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Text(
                            text = myRankText,
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PodiumSection(
    topThree: List<LeaderboardEntry>,
    isDaily: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        val second = topThree.getOrNull(1)
        val first = topThree.getOrNull(0)
        val third = topThree.getOrNull(2)

        if (second != null) {
            PodiumCard(
                rank = 2,
                entry = second,
                isDaily = isDaily,
                accent = Color(0xFF94A3B8),
                modifier = Modifier.weight(1f)
            )
        }
        if (first != null) {
            PodiumCard(
                rank = 1,
                entry = first,
                isDaily = isDaily,
                accent = CoinGold,
                modifier = Modifier.weight(1.1f)
            )
        }
        if (third != null) {
            PodiumCard(
                rank = 3,
                entry = third,
                isDaily = isDaily,
                accent = Color(0xFFD97706),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun PodiumCard(
    rank: Int,
    entry: LeaderboardEntry,
    isDaily: Boolean,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val coins = if (isDaily) entry.dailyCoins else entry.weeklyCoins
    QuestCard(modifier = modifier, contentPadding = PaddingValues(12.dp)) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = accent.copy(alpha = 0.18f)
            ) {
                Text(
                    text = "#$rank",
                    style = MaterialTheme.typography.labelLarge,
                    color = accent,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            InitialsAvatar(name = entry.displayName, size = if (rank == 1) 48.dp else 40.dp, backgroundColor = accent)
            Spacer(Modifier.height(6.dp))
            Text(
                text = entry.displayName,
                style = MaterialTheme.typography.titleSmall,
                color = PrimaryText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "+$coins",
                style = MaterialTheme.typography.labelLarge,
                color = PrimaryBlue
            )
        }
    }
}
