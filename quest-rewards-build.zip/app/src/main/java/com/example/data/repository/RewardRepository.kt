package com.example.data.repository

import com.example.config.TestConfig
import com.example.data.local.CompletedTaskEntity
import com.example.data.local.GameRoundEntity
import com.example.data.local.OfferSessionEntity
import com.example.data.local.OfferStatus
import com.example.data.local.QuestDao
import com.example.data.local.TransactionEntity
import com.example.data.local.UserBalanceEntity
import com.example.data.remote.FirebaseManager
import com.example.data.remote.PayoutMethod
import com.example.data.remote.TaskItem
import com.example.data.remote.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RewardRepository(
    private val questDao: QuestDao,
    private val firebaseManager: FirebaseManager
) {
    val balance: Flow<UserBalanceEntity> = questDao.observeBalance()
        .map { it ?: UserBalanceEntity(id = 1, coins = TestConfig.INITIAL_COINS, gems = TestConfig.INITIAL_GEMS) }

    val offerSessions: Flow<List<OfferSessionEntity>> = questDao.observeOfferSessions()

    val activeOfferSession: Flow<OfferSessionEntity?> = questDao.observeActiveOfferSession()

    val completedOfferCount: Flow<Int> = questDao.observeCompletedOfferCount()

    val transactions: Flow<List<TransactionEntity>> = questDao.observeTransactions()

    val completedTaskIds: Flow<Set<String>> = questDao.observeCompletedTasks()
        .map { list -> list.map { it.taskId }.toSet() }

    fun observeOfferSession(sessionId: Long): Flow<OfferSessionEntity?> =
        questDao.observeOfferSession(sessionId)

    suspend fun syncFromRemoteProfile(profile: UserProfile) {
        val current = questDao.getBalance()
        val updated = UserBalanceEntity(
            id = 1,
            coins = profile.coins,
            gems = profile.gems
        )
        if (current != updated) {
            questDao.upsertBalance(updated)
        }
    }

    suspend fun ensureLocalWelcomeBonus(welcomeCoins: Int, welcomeGems: Int) {
        val existing = questDao.getBalance()
        if (existing == null) {
            questDao.upsertBalance(
                UserBalanceEntity(
                    id = 1,
                    coins = welcomeCoins,
                    gems = welcomeGems
                )
            )
            questDao.insertTransaction(
                TransactionEntity(
                    title = "Welcome Bonus (Local Mode)",
                    type = "EARN",
                    coinsDelta = welcomeCoins,
                    gemsDelta = welcomeGems,
                    status = "Success"
                )
            )
        }
    }

    suspend fun clearLocalUserData() {
        questDao.clearBalance()
        questDao.clearGameRounds()
        questDao.clearOfferSessions()
        questDao.clearTransactions()
        questDao.clearCompletedTasks()
    }

    suspend fun awardGameRoundGem(roundId: String, gemAmount: Int): Boolean {
        val existingRound = questDao.getGameRound(roundId)
        if (existingRound != null) return false

        val inserted = questDao.insertGameRound(
            GameRoundEntity(roundId = roundId, gemsAwarded = gemAmount)
        )
        if (inserted == -1L) return false

        val current = questDao.getBalance() ?: UserBalanceEntity()
        val newGems = current.gems + gemAmount
        questDao.upsertBalance(current.copy(gems = newGems))

        val txTitle = "Image Finder Gem Reward"
        questDao.insertTransaction(
            TransactionEntity(
                title = txTitle,
                type = "EARN",
                coinsDelta = 0,
                gemsDelta = gemAmount,
                status = "Success"
            )
        )

        firebaseManager.syncBalance(coins = current.coins, gems = newGems, earnedCoinsDelta = 0)
        firebaseManager.recordRemoteTransaction(
            title = txTitle,
            type = "EARN",
            coinsDelta = 0,
            gemsDelta = gemAmount
        )
        return true
    }

    suspend fun unlockSuperOffer(
        requiredGems: Int,
        requiredUsageSeconds: Int,
        initialPackages: Set<String>
    ): Result<Long> {
        val current = questDao.getBalance() ?: UserBalanceEntity()
        if (current.gems < requiredGems) {
            return Result.failure(
                IllegalStateException("You need $requiredGems Gems to unlock this Super Offer.")
            )
        }

        val newGems = current.gems - requiredGems
        questDao.upsertBalance(current.copy(gems = newGems))

        val snapshotSerialized = initialPackages.sorted().joinToString(",")
        val now = System.currentTimeMillis()
        val sessionId = questDao.insertOfferSession(
            OfferSessionEntity(
                status = OfferStatus.NOT_STARTED,
                requiredUsageSeconds = requiredUsageSeconds,
                initialPackagesSnapshot = snapshotSerialized,
                createdAt = now,
                updatedAt = now
            )
        )

        val txTitle = "Super Offer Unlocked"
        questDao.insertTransaction(
            TransactionEntity(
                title = txTitle,
                type = "UNLOCK",
                coinsDelta = 0,
                gemsDelta = -requiredGems,
                status = "Success"
            )
        )

        firebaseManager.syncBalance(coins = current.coins, gems = newGems, earnedCoinsDelta = 0)
        firebaseManager.recordRemoteTransaction(
            title = txTitle,
            type = "UNLOCK",
            coinsDelta = 0,
            gemsDelta = -requiredGems
        )

        return Result.success(sessionId)
    }

    suspend fun recordAdWatched(sessionId: Long) {
        val session = questDao.getOfferSession(sessionId) ?: return
        if (session.adWatched) return
        val nextStatus = if (session.status == OfferStatus.NOT_STARTED) {
            OfferStatus.IN_PROGRESS
        } else {
            session.status
        }
        questDao.updateOfferSession(
            session.copy(
                adWatched = true,
                status = nextStatus,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun setTargetApplication(sessionId: Long, packageName: String, appName: String) {
        val session = questDao.getOfferSession(sessionId) ?: return
        questDao.updateOfferSession(
            session.copy(
                targetPackage = packageName,
                targetAppName = appName,
                status = if (session.status == OfferStatus.NOT_STARTED) OfferStatus.IN_PROGRESS else session.status,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateUsageProgress(sessionId: Long, observedSeconds: Int) {
        val session = questDao.getOfferSession(sessionId) ?: return
        if (session.status == OfferStatus.COMPLETED || session.status == OfferStatus.REJECTED) return
        val clamped = observedSeconds.coerceAtLeast(session.observedUsageSeconds)
        val nextStatus = if (clamped >= session.requiredUsageSeconds && session.adWatched && session.targetPackage != null) {
            OfferStatus.PENDING_VERIFICATION
        } else if (session.adWatched) {
            OfferStatus.IN_PROGRESS
        } else {
            session.status
        }
        questDao.updateOfferSession(
            session.copy(
                observedUsageSeconds = clamped,
                status = nextStatus,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun completeOfferAndClaimCoins(sessionId: Long, coinReward: Int): Result<Unit> {
        val session = questDao.getOfferSession(sessionId)
            ?: return Result.failure(IllegalStateException("Offer session not found."))
        if (session.coinsRewarded || session.status == OfferStatus.COMPLETED) {
            return Result.failure(IllegalStateException("Reward already claimed for this offer."))
        }
        if (!session.adWatched || session.targetPackage.isNullOrBlank() ||
            session.observedUsageSeconds < session.requiredUsageSeconds
        ) {
            return Result.failure(IllegalStateException("Complete all steps before claiming coins."))
        }

        questDao.updateOfferSession(
            session.copy(
                coinsRewarded = true,
                status = OfferStatus.COMPLETED,
                updatedAt = System.currentTimeMillis()
            )
        )

        val current = questDao.getBalance() ?: UserBalanceEntity()
        val newCoins = current.coins + coinReward
        questDao.upsertBalance(current.copy(coins = newCoins))

        val txTitle = "Super Offer Completed (${session.targetAppName ?: "Partner App"})"
        questDao.insertTransaction(
            TransactionEntity(
                title = txTitle,
                type = "EARN",
                coinsDelta = coinReward,
                gemsDelta = 0,
                status = "Success"
            )
        )

        firebaseManager.syncBalance(coins = newCoins, gems = current.gems, earnedCoinsDelta = coinReward)
        firebaseManager.recordRemoteTransaction(
            title = txTitle,
            type = "EARN",
            coinsDelta = coinReward,
            gemsDelta = 0
        )

        return Result.success(Unit)
    }

    suspend fun completeTaskAndClaimCoins(task: TaskItem): Result<Unit> {
        if (questDao.getCompletedTask(task.id) != null) {
            return Result.failure(IllegalStateException("Task already completed."))
        }
        val inserted = questDao.insertCompletedTask(
            CompletedTaskEntity(
                taskId = task.id,
                title = task.title,
                rewardCoins = task.rewardCoins
            )
        )
        if (inserted == -1L) {
            return Result.failure(IllegalStateException("Task already completed."))
        }

        val current = questDao.getBalance() ?: UserBalanceEntity()
        val newCoins = current.coins + task.rewardCoins
        questDao.upsertBalance(current.copy(coins = newCoins))

        val txTitle = "Task: ${task.title}"
        questDao.insertTransaction(
            TransactionEntity(
                title = txTitle,
                type = "EARN",
                coinsDelta = task.rewardCoins,
                gemsDelta = 0,
                status = "Success"
            )
        )

        firebaseManager.recordCompletedTask(task.id, task.rewardCoins)
        firebaseManager.syncBalance(coins = newCoins, gems = current.gems, earnedCoinsDelta = task.rewardCoins)
        firebaseManager.recordRemoteTransaction(
            title = txTitle,
            type = "EARN",
            coinsDelta = task.rewardCoins,
            gemsDelta = 0
        )
        return Result.success(Unit)
    }

    suspend fun requestWithdrawal(
        method: PayoutMethod,
        accountDetail: String,
        coinsToDeduct: Int,
        cashAmount: Double
    ): Result<Unit> {
        val current = questDao.getBalance() ?: UserBalanceEntity()
        if (current.coins < coinsToDeduct) {
            return Result.failure(
                IllegalStateException("Insufficient coins. Need ${coinsToDeduct - current.coins} more coins.")
            )
        }
        if (accountDetail.isBlank() || accountDetail.trim().length < 3) {
            return Result.failure(IllegalStateException("Please enter valid payout account details."))
        }

        val newCoins = current.coins - coinsToDeduct
        questDao.upsertBalance(current.copy(coins = newCoins))

        val txTitle = "${method.name} Withdrawal (₹${cashAmount.toInt()})"
        questDao.insertTransaction(
            TransactionEntity(
                title = txTitle,
                type = "WITHDRAW",
                coinsDelta = -coinsToDeduct,
                gemsDelta = 0,
                status = "Success"
            )
        )

        val remoteResult = firebaseManager.createWithdrawal(
            method = method,
            accountDetail = accountDetail,
            coinsDeducted = coinsToDeduct,
            cashAmount = cashAmount
        )
        firebaseManager.syncBalance(coins = newCoins, gems = current.gems, earnedCoinsDelta = 0)
        firebaseManager.recordRemoteTransaction(
            title = txTitle,
            type = "WITHDRAW",
            coinsDelta = -coinsToDeduct,
            gemsDelta = 0
        )

        return if (remoteResult.isSuccess) Result.success(Unit) else Result.success(Unit)
    }
}
