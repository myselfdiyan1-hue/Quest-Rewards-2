package com.example.data.remote

import com.example.config.TestConfig
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String? = null,
    val coins: Int = TestConfig.INITIAL_COINS,
    val gems: Int = TestConfig.INITIAL_GEMS,
    val dailyCoins: Int = 0,
    val weeklyCoins: Int = 0,
    val lastDailyDate: String = "",
    val lastWeeklyDate: String = "",
    @get:PropertyName("isBlocked") @set:PropertyName("isBlocked")
    var isBlocked: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class LeaderboardEntry(
    @DocumentId val id: String = "",
    val uid: String = "",
    val displayName: String = "Player",
    val photoUrl: String? = null,
    val dailyCoins: Int = 0,
    val weeklyCoins: Int = 0,
    val lastDailyDate: String = "",
    val lastWeeklyDate: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AppConfig(
    @DocumentId val id: String = "",
    val superOfferUnlockCoins: Int = TestConfig.SUPER_OFFER_COIN_REWARD,
    val superOfferUnlockGems: Int = TestConfig.SUPER_OFFER_REQUIRED_GEMS,
    @get:PropertyName("isSuperOfferEnabled") @set:PropertyName("isSuperOfferEnabled")
    var isSuperOfferEnabled: Boolean = true,
    val minWithdrawalCoins: Int = 1000,
    val welcomeBonusCoins: Int = TestConfig.WELCOME_BONUS_COINS,
    val welcomeBonusGems: Int = TestConfig.WELCOME_BONUS_GEMS,
    val requiredUsageSeconds: Int = TestConfig.REQUIRED_USAGE_SECONDS,
    val gemRewardPerRound: Int = TestConfig.GEM_REWARD_PER_ROUND
)

@IgnoreExtraProperties
data class PayoutMethod(
    @DocumentId val id: String = "",
    val name: String = "",
    val icon: String = "",
    val minCoins: Int = 1000,
    val cashAmount: Double = 10.0,
    val currency: String = "INR",
    val instructions: String = "",
    @get:PropertyName("isEnabled") @set:PropertyName("isEnabled")
    var isEnabled: Boolean = true
)

@IgnoreExtraProperties
data class WithdrawalRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val payoutMethodId: String = "",
    val payoutMethodName: String = "",
    val accountDetail: String = "",
    val coinsDeducted: Int = 0,
    val cashAmount: Double = 0.0,
    val status: String = "pending",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TaskItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val rewardCoins: Int = 0,
    val category: String = "General",
    val iconType: String = "mission",
    val actionUrl: String = "",
    @get:PropertyName("isEnabled") @set:PropertyName("isEnabled")
    var isEnabled: Boolean = true
)

@IgnoreExtraProperties
data class TaskCategory(
    @DocumentId val id: String = "",
    val name: String = "",
    val iconType: String = "category",
    @get:PropertyName("isEnabled") @set:PropertyName("isEnabled")
    var isEnabled: Boolean = true,
    val order: Int = 0
)

object BuiltInPayoutMethods {
    val defaults = listOf(
        PayoutMethod(
            id = "PAYTM",
            name = "Paytm Wallet",
            icon = "paytm",
            minCoins = 1000,
            cashAmount = 10.0,
            currency = "INR",
            instructions = "Enter 10-digit Paytm Mobile No.",
            isEnabled = true
        ),
        PayoutMethod(
            id = "UPI",
            name = "UPI ID / QR",
            icon = "upi",
            minCoins = 1000,
            cashAmount = 10.0,
            currency = "INR",
            instructions = "username@okhdfcbank / number@upi",
            isEnabled = true
        ),
        PayoutMethod(
            id = "BANK",
            name = "Bank Transfer",
            icon = "bank",
            minCoins = 1000,
            cashAmount = 10.0,
            currency = "INR",
            instructions = "Account Number & IFSC Code",
            isEnabled = true
        )
    )
}
