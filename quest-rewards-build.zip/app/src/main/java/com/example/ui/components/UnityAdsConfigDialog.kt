package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.ads.UnityAdsConfig
import com.example.ads.UnityRewardedAdManager
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SecondaryText

@Composable
fun UnityAdsConfigDialog(
    adManager: UnityRewardedAdManager,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var appKey by remember {
        mutableStateOf(UnityAdsConfig.getEffectiveAppKey(context))
    }
    var rewardedId by remember { mutableStateOf(UnityAdsConfig.getEffectiveRewardedId(context)) }
    var interstitialId by remember { mutableStateOf(UnityAdsConfig.getEffectiveInterstitialId(context)) }
    var bannerId by remember { mutableStateOf(UnityAdsConfig.getEffectiveBannerId(context)) }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("LevelPlay Ads Configuration") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Enter your LevelPlay App Key and Ad Unit IDs from the LevelPlay Dashboard.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SecondaryText
                )
                OutlinedTextField(
                    value = appKey,
                    onValueChange = {
                        appKey = it
                        validationError = null
                    },
                    label = { Text("LevelPlay App Key") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = rewardedId,
                    onValueChange = { rewardedId = it },
                    label = { Text("Rewarded Ad Unit ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = interstitialId,
                    onValueChange = { interstitialId = it },
                    label = { Text("Interstitial Ad Unit ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = bannerId,
                    onValueChange = { bannerId = it },
                    label = { Text("Banner Ad Unit ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                validationError?.let {
                    Spacer(Modifier.height(2.dp))
                    Text(text = it, style = MaterialTheme.typography.bodySmall, color = ErrorRed)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val trimmed = appKey.trim()
                if (trimmed.isEmpty()) {
                    validationError = "Please enter a valid LevelPlay App Key."
                    return@Button
                }
                adManager.reinitializeWithConfig(
                    gameId = trimmed,
                    rewardedId = rewardedId.ifBlank { UnityAdsConfig.REWARDED_AD_UNIT_ID },
                    interstitialId = interstitialId.ifBlank { UnityAdsConfig.INTERSTITIAL_AD_UNIT_ID },
                    bannerId = bannerId.ifBlank { UnityAdsConfig.BANNER_AD_UNIT_ID }
                )
                onDismiss()
            }) {
                Text("Save & Initialize")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
