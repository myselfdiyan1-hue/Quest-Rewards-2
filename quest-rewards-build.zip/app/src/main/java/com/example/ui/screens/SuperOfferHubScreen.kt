package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.OfferStatus
import com.example.ui.components.CoinBadge
import com.example.ui.components.GemBadge
import com.example.ui.components.QuestCard
import com.example.ui.theme.CardWhite
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.SuperOfferViewModel

@Composable
fun SuperOfferHubScreen(
    viewModel: SuperOfferViewModel,
    onBack: () -> Unit,
    onNavigateToDetails: () -> Unit,
    onNavigateToUsagePermission: () -> Unit
) {
    val balance by viewModel.balance.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val sessions by viewModel.offerSessions.collectAsStateWithLifecycle()
    val activeSession by viewModel.activeOfferSession.collectAsStateWithLifecycle()
    val completedCount by viewModel.completedOfferCount.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Surface(color = HeaderBackground, shadowElevation = 4.dp) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("super_offer_back")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PrimaryText)
                        }
                        Text(
                            text = "Super Offer",
                            style = MaterialTheme.typography.headlineMedium,
                            color = PrimaryText
                        )
                    }
                    GemBadge(amountText = "${balance.gems}", animatePulse = true)
                }

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = HeaderBackground,
                    contentColor = PrimaryBlue
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Offers") },
                        modifier = Modifier.testTag("tab_offers")
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("History") },
                        modifier = Modifier.testTag("tab_offer_history")
                    )
                }
            }
        }

        if (statusBanner != null) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                color = ErrorRed.copy(alpha = 0.12f)
            ) {
                Text(
                    text = statusBanner ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrorRed,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedTab == 0) {
                item {
                    QuestCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Offer Completed",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PrimaryText
                                )
                            }
                            Text(
                                text = "$completedCount",
                                style = MaterialTheme.typography.headlineSmall,
                                color = PrimaryBlue
                            )
                        }
                    }
                }

                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(PrimaryBlue, PurpleAccent)))
                            .padding(20.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = OrangeAccent
                                ) {
                                    Text(
                                        text = "SPECIAL",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                CoinBadge(amountText = "+${appConfig.superOfferUnlockCoins} Coins")
                            }

                            Spacer(Modifier.height(14.dp))
                            Text(
                                text = "SPECIAL: Watch Ads & Install App!",
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "Requires ${appConfig.superOfferUnlockGems} Gems to unlock. Watch the video Ad, install the partner app, and use it for ${appConfig.requiredUsageSeconds}s.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )

                            Spacer(Modifier.height(16.dp))

                            if (activeSession != null) {
                                Button(
                                    onClick = { onNavigateToDetails() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("resume_super_offer_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CardWhite,
                                        contentColor = PrimaryBlue
                                    )
                                ) {
                                    Icon(Icons.Filled.CardGiftcard, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Continue Active Offer", fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Button(
                                    onClick = {
                                        viewModel.clearBanner()
                                        viewModel.unlockSuperOffer(onUnlocked = onNavigateToDetails)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("unlock_super_offer_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CardWhite,
                                        contentColor = PrimaryBlue
                                    )
                                ) {
                                    Icon(Icons.Filled.LockOpen, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Unlock Offer (${appConfig.superOfferUnlockGems} Gems)",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                if (!viewModel.hasUsagePermission()) {
                    item {
                        QuestCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Tracking Mode: Built-in Session Timer",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = PrimaryText
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = "No Usage Access permission needed — works even if Android shows \"Access denied for this app\".",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SecondaryText
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                TextButton(
                                    onClick = onNavigateToUsagePermission,
                                    modifier = Modifier.testTag("optional_usage_settings_button")
                                ) {
                                    Text("OS Settings")
                                }
                            }
                        }
                    }
                }
            } else {
                if (sessions.isEmpty()) {
                    item {
                        QuestCard(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.History,
                                    contentDescription = null,
                                    tint = SecondaryText,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    text = "No Offer History",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PrimaryText
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "Complete your first Super Offer to see it recorded here.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SecondaryText,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    items(sessions, key = { it.id }) { session ->
                        QuestCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = session.targetAppName ?: "Super Offer #${session.id}",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = PrimaryText
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = "Reward: \uD83E\uDE99 ${appConfig.superOfferUnlockCoins} Coins • Usage: ${session.observedUsageSeconds}/${session.requiredUsageSeconds}s",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SecondaryText
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = when (session.status) {
                                        OfferStatus.COMPLETED -> SuccessGreen.copy(alpha = 0.14f)
                                        OfferStatus.REJECTED -> ErrorRed.copy(alpha = 0.14f)
                                        else -> PrimaryBlue.copy(alpha = 0.12f)
                                    }
                                ) {
                                    Text(
                                        text = session.status.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = when (session.status) {
                                            OfferStatus.COMPLETED -> SuccessGreen
                                            OfferStatus.REJECTED -> ErrorRed
                                            else -> PrimaryBlue
                                        },
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UsagePermissionScreen(
    viewModel: SuperOfferViewModel,
    onBack: () -> Unit,
    onPermissionGranted: () -> Unit
) {
    var statusMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        QuestCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Filled.Security,
                    contentDescription = "Usage Access",
                    tint = PrimaryBlue,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "Allow Usage Access",
                    style = MaterialTheme.typography.headlineSmall,
                    color = PrimaryText,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Android 13+ blocks Usage Access on sideloaded APKs with \"Access denied for this app\" until Restricted Settings are unlocked:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SecondaryText,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PrimaryBlue.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "1. Tap \"Open App Info\" below",
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryText,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "2. Tap ⋮ (top-right menu) -> Allow restricted settings",
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryText,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "3. Return here and tap \"Open Usage Access Settings\" to toggle ON",
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryText,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                statusMessage?.let { msg ->
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = OrangeAccent,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(Modifier.height(16.dp))
                OutlinedButton(
                    onClick = { viewModel.openAppInfoSettings() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_app_info_settings_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("1. Open App Info (Allow Restricted)")
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.openUsageAccessSettings() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("open_usage_settings_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("2. Open Usage Access Settings")
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (viewModel.hasUsagePermission()) {
                            onPermissionGranted()
                        } else {
                            statusMessage = "Usage Access is still disabled by Android. Unlock Restricted Settings in App Info first, or use Session Timer Fallback below."
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("verify_usage_permission_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SuccessGreen,
                        contentColor = Color.White
                    )
                ) {
                    Text("I Enabled Usage Access")
                }
                Spacer(Modifier.height(6.dp))
                TextButton(
                    onClick = onBack,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("usage_permission_fallback_button")
                ) {
                    Text("Back (Use Session Timer Fallback)")
                }
            }
        }
    }
}
