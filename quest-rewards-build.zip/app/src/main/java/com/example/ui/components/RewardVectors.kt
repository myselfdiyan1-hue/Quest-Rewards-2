package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CoinGold
import com.example.ui.theme.GemCyan
import com.example.ui.theme.YellowAccent
import com.example.ui.viewmodel.GameObjectType

@Composable
fun CoinVectorIcon(
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    animatePulse: Boolean = false
) {
    val scale = if (animatePulse) {
        val transition = rememberInfiniteTransition(label = "coin_pulse")
        val anim by transition.animateFloat(
            initialValue = 0.96f,
            targetValue = 1.07f,
            animationSpec = infiniteRepeatable(
                animation = tween(900, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "coin_scale"
        )
        anim
    } else 1f

    Canvas(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
    ) {
        val r = this.size.minDimension / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)

        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(YellowAccent, CoinGold, Color(0xFFD98A00))
            ),
            radius = r,
            center = center
        )
        drawCircle(
            color = Color(0xFFFFF0A6),
            radius = r * 0.78f,
            center = center,
            style = Stroke(width = r * 0.14f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFE066), CoinGold),
                center = Offset(center.x - r * 0.2f, center.y - r * 0.2f),
                radius = r * 0.85f
            ),
            radius = r * 0.65f,
            center = center
        )
        // Embossed star/diamond center
        val star = Path().apply {
            moveTo(center.x, center.y - r * 0.34f)
            lineTo(center.x + r * 0.14f, center.y - r * 0.1f)
            lineTo(center.x + r * 0.36f, center.y)
            lineTo(center.x + r * 0.14f, center.y + r * 0.1f)
            lineTo(center.x, center.y + r * 0.34f)
            lineTo(center.x - r * 0.14f, center.y + r * 0.1f)
            lineTo(center.x - r * 0.36f, center.y)
            lineTo(center.x - r * 0.14f, center.y - r * 0.1f)
            close()
        }
        drawPath(star, color = Color(0xFFFFF8CC))
    }
}

@Composable
fun GemVectorIcon(
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    animatePulse: Boolean = false
) {
    val scale = if (animatePulse) {
        val transition = rememberInfiniteTransition(label = "gem_pulse")
        val anim by transition.animateFloat(
            initialValue = 0.94f,
            targetValue = 1.09f,
            animationSpec = infiniteRepeatable(
                animation = tween(850, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "gem_scale"
        )
        anim
    } else 1f

    Canvas(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
    ) {
        val w = this.size.width
        val h = this.size.height

        val topLeft = Offset(w * 0.22f, h * 0.14f)
        val topRight = Offset(w * 0.78f, h * 0.14f)
        val midLeft = Offset(w * 0.06f, h * 0.40f)
        val midRight = Offset(w * 0.94f, h * 0.40f)
        val bottom = Offset(w * 0.50f, h * 0.92f)
        val innerLeft = Offset(w * 0.34f, h * 0.40f)
        val innerRight = Offset(w * 0.66f, h * 0.40f)
        val topCenterLeft = Offset(w * 0.38f, h * 0.14f)
        val topCenterRight = Offset(w * 0.62f, h * 0.14f)

        // Base fill
        val full = Path().apply {
            moveTo(topLeft.x, topLeft.y)
            lineTo(topRight.x, topRight.y)
            lineTo(midRight.x, midRight.y)
            lineTo(bottom.x, bottom.y)
            lineTo(midLeft.x, midLeft.y)
            close()
        }
        drawPath(full, color = GemCyan)

        // Top center bright facet
        val topCenter = Path().apply {
            moveTo(topCenterLeft.x, topCenterLeft.y)
            lineTo(topCenterRight.x, topCenterRight.y)
            lineTo(innerRight.x, innerRight.y)
            lineTo(innerLeft.x, innerLeft.y)
            close()
        }
        drawPath(topCenter, color = Color(0xFFB3F3FF))

        // Left crown
        val leftCrown = Path().apply {
            moveTo(topLeft.x, topLeft.y)
            lineTo(topCenterLeft.x, topCenterLeft.y)
            lineTo(innerLeft.x, innerLeft.y)
            lineTo(midLeft.x, midLeft.y)
            close()
        }
        drawPath(leftCrown, color = Color(0xFF66DCFF))

        // Right crown
        val rightCrown = Path().apply {
            moveTo(topCenterRight.x, topCenterRight.y)
            lineTo(topRight.x, topRight.y)
            lineTo(midRight.x, midRight.y)
            lineTo(innerRight.x, innerRight.y)
            close()
        }
        drawPath(rightCrown, color = Color(0xFF009AD4))

        // Bottom left facet
        val bottomLeft = Path().apply {
            moveTo(midLeft.x, midLeft.y)
            lineTo(innerLeft.x, innerLeft.y)
            lineTo(bottom.x, bottom.y)
            close()
        }
        drawPath(bottomLeft, color = Color(0xFF14A9DE))

        // Bottom center facet
        val bottomCenter = Path().apply {
            moveTo(innerLeft.x, innerLeft.y)
            lineTo(innerRight.x, innerRight.y)
            lineTo(bottom.x, bottom.y)
            close()
        }
        drawPath(bottomCenter, color = Color(0xFF7CE7FF))

        // Bottom right facet
        val bottomRight = Path().apply {
            moveTo(innerRight.x, innerRight.y)
            lineTo(midRight.x, midRight.y)
            lineTo(bottom.x, bottom.y)
            close()
        }
        drawPath(bottomRight, color = Color(0xFF0077AD))
    }
}

@Composable
fun ImageFinderObjectVector(
    type: GameObjectType,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        when (type) {
            GameObjectType.APPLE -> {
                // Stem
                drawLine(
                    color = Color(0xFF795548),
                    start = Offset(w * 0.50f, h * 0.25f),
                    end = Offset(w * 0.54f, h * 0.11f),
                    strokeWidth = w * 0.06f,
                    cap = StrokeCap.Round
                )
                // Leaf
                val leaf = Path().apply {
                    moveTo(w * 0.52f, h * 0.18f)
                    quadraticTo(w * 0.72f, h * 0.08f, w * 0.75f, h * 0.24f)
                    quadraticTo(w * 0.60f, h * 0.28f, w * 0.52f, h * 0.18f)
                }
                drawPath(leaf, color = Color(0xFF10B981))
                // Apple body
                drawCircle(
                    color = Color(0xFFEF4444),
                    radius = w * 0.26f,
                    center = Offset(w * 0.40f, h * 0.55f)
                )
                drawCircle(
                    color = Color(0xFFEF4444),
                    radius = w * 0.26f,
                    center = Offset(w * 0.60f, h * 0.55f)
                )
                drawOval(
                    color = Color(0xFFDC2626),
                    topLeft = Offset(w * 0.22f, h * 0.42f),
                    size = Size(w * 0.56f, h * 0.44f)
                )
                // Gloss highlight
                drawCircle(
                    color = Color(0x66FFFFFF),
                    radius = w * 0.08f,
                    center = Offset(w * 0.36f, h * 0.44f)
                )
            }

            GameObjectType.CAR -> {
                // Car roof
                val roof = Path().apply {
                    moveTo(w * 0.25f, h * 0.48f)
                    lineTo(w * 0.36f, h * 0.26f)
                    lineTo(w * 0.66f, h * 0.26f)
                    lineTo(w * 0.77f, h * 0.48f)
                    close()
                }
                drawPath(roof, color = Color(0xFF385BEE))
                // Windows
                val win = Path().apply {
                    moveTo(w * 0.30f, h * 0.46f)
                    lineTo(w * 0.38f, h * 0.31f)
                    lineTo(w * 0.63f, h * 0.31f)
                    lineTo(w * 0.71f, h * 0.46f)
                    close()
                }
                drawPath(win, color = Color(0xFFBEE3FF))
                // Car body
                drawRoundRect(
                    color = Color(0xFF385BEE),
                    topLeft = Offset(w * 0.12f, h * 0.46f),
                    size = Size(w * 0.76f, h * 0.25f),
                    cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
                )
                // Headlight
                drawCircle(
                    color = Color(0xFFFFD52E),
                    radius = w * 0.045f,
                    center = Offset(w * 0.82f, h * 0.56f)
                )
                // Wheels
                drawCircle(Color(0xFF17192B), radius = w * 0.11f, center = Offset(w * 0.30f, h * 0.72f))
                drawCircle(Color(0xFFE2E7FA), radius = w * 0.05f, center = Offset(w * 0.30f, h * 0.72f))
                drawCircle(Color(0xFF17192B), radius = w * 0.11f, center = Offset(w * 0.70f, h * 0.72f))
                drawCircle(Color(0xFFE2E7FA), radius = w * 0.05f, center = Offset(w * 0.70f, h * 0.72f))
            }

            GameObjectType.BANANA -> {
                val banana = Path().apply {
                    moveTo(w * 0.22f, h * 0.68f)
                    quadraticTo(w * 0.62f, h * 0.85f, w * 0.82f, h * 0.24f)
                    quadraticTo(w * 0.70f, h * 0.20f, w * 0.68f, h * 0.28f)
                    quadraticTo(w * 0.52f, h * 0.62f, w * 0.18f, h * 0.58f)
                    close()
                }
                drawPath(banana, color = Color(0xFFFFD52E))
                drawPath(
                    banana,
                    color = Color(0xFFEAB308),
                    style = Stroke(width = w * 0.03f, join = StrokeJoin.Round)
                )
                // Stem tip
                drawLine(
                    color = Color(0xFF78350F),
                    start = Offset(w * 0.78f, h * 0.23f),
                    end = Offset(w * 0.83f, h * 0.15f),
                    strokeWidth = w * 0.055f,
                    cap = StrokeCap.Round
                )
            }

            GameObjectType.DOG -> {
                // Ears
                drawOval(
                    color = Color(0xFF92400E),
                    topLeft = Offset(w * 0.16f, h * 0.24f),
                    size = Size(w * 0.18f, h * 0.34f)
                )
                drawOval(
                    color = Color(0xFF92400E),
                    topLeft = Offset(w * 0.66f, h * 0.24f),
                    size = Size(w * 0.18f, h * 0.34f)
                )
                // Head
                drawCircle(
                    color = Color(0xFFD97706),
                    radius = w * 0.28f,
                    center = Offset(w * 0.50f, h * 0.50f)
                )
                // Snout
                drawOval(
                    color = Color(0xFFFDE68A),
                    topLeft = Offset(w * 0.34f, h * 0.50f),
                    size = Size(w * 0.32f, h * 0.24f)
                )
                // Eyes
                drawCircle(Color(0xFF17192B), radius = w * 0.042f, center = Offset(w * 0.39f, h * 0.44f))
                drawCircle(Color(0xFF17192B), radius = w * 0.042f, center = Offset(w * 0.61f, h * 0.44f))
                // Nose & tongue
                drawOval(
                    color = Color(0xFF17192B),
                    topLeft = Offset(w * 0.44f, h * 0.53f),
                    size = Size(w * 0.12f, h * 0.08f)
                )
                drawOval(
                    color = Color(0xFFEF4444),
                    topLeft = Offset(w * 0.46f, h * 0.65f),
                    size = Size(w * 0.08f, h * 0.11f)
                )
            }

            GameObjectType.FOOTBALL -> {
                val center = Offset(w * 0.5f, h * 0.5f)
                val r = w * 0.34f
                drawCircle(color = Color.White, radius = r, center = center)
                drawCircle(color = Color(0xFF17192B), radius = r, center = center, style = Stroke(width = w * 0.04f))
                // Center pentagon
                val pent = Path().apply {
                    moveTo(w * 0.50f, h * 0.36f)
                    lineTo(w * 0.63f, h * 0.46f)
                    lineTo(w * 0.58f, h * 0.61f)
                    lineTo(w * 0.42f, h * 0.61f)
                    lineTo(w * 0.37f, h * 0.46f)
                    close()
                }
                drawPath(pent, color = Color(0xFF17192B))
                // Spokes + edge patches
                drawLine(Color(0xFF17192B), Offset(w * 0.50f, h * 0.36f), Offset(w * 0.50f, h * 0.18f), w * 0.03f)
                drawLine(Color(0xFF17192B), Offset(w * 0.63f, h * 0.46f), Offset(w * 0.80f, h * 0.40f), w * 0.03f)
                drawLine(Color(0xFF17192B), Offset(w * 0.37f, h * 0.46f), Offset(w * 0.20f, h * 0.40f), w * 0.03f)
                drawLine(Color(0xFF17192B), Offset(w * 0.58f, h * 0.61f), Offset(w * 0.70f, h * 0.76f), w * 0.03f)
                drawLine(Color(0xFF17192B), Offset(w * 0.42f, h * 0.61f), Offset(w * 0.30f, h * 0.76f), w * 0.03f)
            }

            GameObjectType.CAT -> {
                // Pointed ears
                val leftEar = Path().apply {
                    moveTo(w * 0.24f, h * 0.42f)
                    lineTo(w * 0.26f, h * 0.16f)
                    lineTo(w * 0.44f, h * 0.32f)
                    close()
                }
                val rightEar = Path().apply {
                    moveTo(w * 0.76f, h * 0.42f)
                    lineTo(w * 0.74f, h * 0.16f)
                    lineTo(w * 0.56f, h * 0.32f)
                    close()
                }
                drawPath(leftEar, color = Color(0xFF852BEE))
                drawPath(rightEar, color = Color(0xFF852BEE))
                // Face
                drawCircle(
                    color = Color(0xFFA8B0F4),
                    radius = w * 0.28f,
                    center = Offset(w * 0.50f, h * 0.54f)
                )
                // Eyes
                drawCircle(Color(0xFF17192B), radius = w * 0.042f, center = Offset(w * 0.39f, h * 0.50f))
                drawCircle(Color(0xFF17192B), radius = w * 0.042f, center = Offset(w * 0.61f, h * 0.50f))
                // Nose
                val nose = Path().apply {
                    moveTo(w * 0.46f, h * 0.58f)
                    lineTo(w * 0.54f, h * 0.58f)
                    lineTo(w * 0.50f, h * 0.64f)
                    close()
                }
                drawPath(nose, color = Color(0xFFEC4899))
                // Whiskers
                drawLine(Color(0xFF17192B), Offset(w * 0.16f, h * 0.56f), Offset(w * 0.32f, h * 0.58f), w * 0.025f)
                drawLine(Color(0xFF17192B), Offset(w * 0.16f, h * 0.64f), Offset(w * 0.32f, h * 0.62f), w * 0.025f)
                drawLine(Color(0xFF17192B), Offset(w * 0.68f, h * 0.58f), Offset(w * 0.84f, h * 0.56f), w * 0.025f)
                drawLine(Color(0xFF17192B), Offset(w * 0.68f, h * 0.62f), Offset(w * 0.84f, h * 0.64f), w * 0.025f)
            }

            GameObjectType.PARROT -> {
                // Body
                drawOval(
                    color = Color(0xFF10B981),
                    topLeft = Offset(w * 0.30f, h * 0.24f),
                    size = Size(w * 0.38f, h * 0.56f)
                )
                // Wing
                drawOval(
                    color = Color(0xFF20BDF0),
                    topLeft = Offset(w * 0.32f, h * 0.42f),
                    size = Size(w * 0.24f, h * 0.32f)
                )
                // Head crest / red chest highlight
                drawCircle(
                    color = Color(0xFFEF4444),
                    radius = w * 0.15f,
                    center = Offset(w * 0.50f, h * 0.32f)
                )
                // Beak
                val beak = Path().apply {
                    moveTo(w * 0.62f, h * 0.26f)
                    quadraticTo(w * 0.84f, h * 0.28f, w * 0.74f, h * 0.42f)
                    lineTo(w * 0.62f, h * 0.36f)
                    close()
                }
                drawPath(beak, color = Color(0xFFFFA51F))
                // Eye
                drawCircle(Color.White, radius = w * 0.05f, center = Offset(w * 0.54f, h * 0.29f))
                drawCircle(Color(0xFF17192B), radius = w * 0.025f, center = Offset(w * 0.55f, h * 0.29f))
            }

            GameObjectType.BICYCLE -> {
                val leftWheel = Offset(w * 0.25f, h * 0.66f)
                val rightWheel = Offset(w * 0.75f, h * 0.66f)
                val r = w * 0.16f
                drawCircle(Color(0xFF17192B), radius = r, center = leftWheel, style = Stroke(width = w * 0.045f))
                drawCircle(Color(0xFF17192B), radius = r, center = rightWheel, style = Stroke(width = w * 0.045f))
                // Frame
                val frameColor = Color(0xFFFFA51F)
                drawLine(frameColor, leftWheel, Offset(w * 0.46f, h * 0.66f), w * 0.045f, StrokeCap.Round)
                drawLine(frameColor, Offset(w * 0.46f, h * 0.66f), Offset(w * 0.64f, h * 0.42f), w * 0.045f, StrokeCap.Round)
                drawLine(frameColor, Offset(w * 0.36f, h * 0.42f), Offset(w * 0.64f, h * 0.42f), w * 0.045f, StrokeCap.Round)
                drawLine(frameColor, leftWheel, Offset(w * 0.36f, h * 0.42f), w * 0.045f, StrokeCap.Round)
                drawLine(frameColor, Offset(w * 0.36f, h * 0.42f), Offset(w * 0.46f, h * 0.66f), w * 0.045f, StrokeCap.Round)
                drawLine(frameColor, Offset(w * 0.61f, h * 0.34f), rightWheel, w * 0.045f, StrokeCap.Round)
                // Seat & handlebar
                drawLine(Color(0xFF17192B), Offset(w * 0.30f, h * 0.38f), Offset(w * 0.42f, h * 0.38f), w * 0.045f, StrokeCap.Round)
                drawLine(Color(0xFF17192B), Offset(w * 0.58f, h * 0.34f), Offset(w * 0.70f, h * 0.34f), w * 0.045f, StrokeCap.Round)
            }

            GameObjectType.TREE -> {
                // Trunk
                drawRoundRect(
                    color = Color(0xFF78350F),
                    topLeft = Offset(w * 0.43f, h * 0.56f),
                    size = Size(w * 0.14f, h * 0.30f),
                    cornerRadius = CornerRadius(w * 0.03f, w * 0.03f)
                )
                // Canopy layers
                drawCircle(Color(0xFF059669), radius = w * 0.22f, center = Offset(w * 0.36f, h * 0.48f))
                drawCircle(Color(0xFF059669), radius = w * 0.22f, center = Offset(w * 0.64f, h * 0.48f))
                drawCircle(Color(0xFF10B981), radius = w * 0.24f, center = Offset(w * 0.50f, h * 0.34f))
            }
        }
    }
}
