package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.remote.BuiltInPayoutMethods
import com.example.ui.components.QuestCard
import com.example.ui.theme.BankEnd
import com.example.ui.theme.BankStart
import com.example.ui.theme.MainBackground
import com.example.ui.theme.PaytmEnd
import com.example.ui.theme.PaytmStart
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceVariant
import com.example.ui.theme.UpiEnd
import com.example.ui.theme.UpiStart
import com.example.ui.viewmodel.MainViewModel

private data class WithdrawalTier(
    val rupees: Int,
    val coins: Int
)

private val withdrawalTiers = listOf(
    WithdrawalTier(10, 1000),
    WithdrawalTier(20, 2000),
    WithdrawalTier(30, 3000),
    WithdrawalTier(40, 4000)
)

@Composable
fun PayoutDetailScreen(
    methodId: String,
    mainViewModel: MainViewModel,
    onBack: () -> Unit
) {
    val balance by mainViewModel.balance.collectAsStateWithLifecycle()
    val payoutMethods by mainViewModel.payoutMethods.collectAsStateWithLifecycle()
    val actionMessage by mainViewModel.actionMessage.collectAsStateWithLifecycle()

    val method = remember(payoutMethods, methodId) {
        payoutMethods.firstOrNull { it.id.equals(methodId, ignoreCase = true) }
            ?: BuiltInPayoutMethods.defaults.firstOrNull { it.id.equals(methodId, ignoreCase = true) }
            ?: BuiltInPayoutMethods.defaults.first()
    }

    val normalized = method.id.uppercase()
    val gradientColors = when {
        normalized.contains("UPI") -> listOf(UpiStart, UpiEnd)
        normalized.contains("BANK") -> listOf(BankStart, BankEnd)
        else -> listOf(PaytmStart, PaytmEnd)
    }

    val hintText = when {
        normalized.contains("UPI") -> "username@okhdfcbank / number@upi"
        normalized.contains("BANK") -> "Account Number & IFSC Code"
        else -> "Enter 10-digit Paytm Mobile No."
    }

    var accountInput by remember { mutableStateOf("") }
    var pendingTier by remember { mutableStateOf<WithdrawalTier?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Method Gradient Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(gradientColors))
                .padding(horizontal = 12.dp, vertical = 16.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("payout_detail_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text(
                        text = "${method.id.uppercase()} Withdrawal",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White
                    )
                }
                Spacer(Modifier.height(6.dp))
                Column(modifier = Modifier.padding(horizontal = 12.dp)) {
                    Text(
                        text = "Your Balance: ${balance.coins} Coins",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Conversion: 1,000 Coins = ₹10 INR. Select any amount below to withdraw.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            actionMessage?.let { msg ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SuccessGreen.copy(alpha = 0.14f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = SuccessGreen,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            QuestCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = method.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = PrimaryText
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = accountInput,
                    onValueChange = { accountInput = it },
                    label = { Text(hintText) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payout_account_input")
                )
            }

            withdrawalTiers.forEach { tier ->
                val progress = (balance.coins.toFloat() / tier.coins.toFloat()).coerceIn(0f, 1f)
                val reached = balance.coins >= tier.coins
                val needed = (tier.coins - balance.coins).coerceAtLeast(0)

                QuestCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("withdraw_tier_${tier.rupees}"),
                    onClick = {
                        if (reached && accountInput.trim().length >= 3) {
                            pendingTier = tier
                        }
                    }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(54.dp)) {
                                CircularProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier.size(54.dp),
                                    color = if (reached) SuccessGreen else gradientColors.first(),
                                    trackColor = SurfaceVariant,
                                    strokeWidth = 5.dp
                                )
                                Text(
                                    text = "₹${tier.rupees}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = PrimaryText,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "₹${tier.rupees} = ${tier.coins} Coins",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = PrimaryText
                                )
                                Text(
                                    text = if (reached) {
                                        "Goal Reached! Click to withdraw ₹${tier.rupees}"
                                    } else {
                                        "Needs $needed more coins"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (reached) SuccessGreen else SecondaryText
                                )
                            }
                        }

                        if (reached) {
                            Button(
                                onClick = { pendingTier = tier },
                                enabled = accountInput.trim().length >= 3,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Withdraw")
                            }
                        }
                    }
                }
            }
        }
    }

    pendingTier?.let { tier ->
        AlertDialog(
            onDismissRequest = { pendingTier = null },
            title = { Text("Confirm Withdrawal") },
            text = {
                Text("${tier.coins} coins will be deducted from your balance.")
            },
            confirmButton = {
                Button(onClick = {
                    val chosen = tier
                    pendingTier = null
                    mainViewModel.requestWithdrawal(
                        method = method,
                        accountDetail = accountInput,
                        coinsToDeduct = chosen.coins,
                        cashAmount = chosen.rupees.toDouble(),
                        onSuccess = { accountInput = "" }
                    )
                }) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingTier = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
