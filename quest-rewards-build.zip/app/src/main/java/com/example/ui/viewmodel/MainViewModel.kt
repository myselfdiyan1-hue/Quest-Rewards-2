package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.TransactionEntity
import com.example.data.local.UserBalanceEntity
import com.example.data.remote.AppConfig
import com.example.data.remote.BuiltInPayoutMethods
import com.example.data.remote.FirebaseManager
import com.example.data.remote.LeaderboardEntry
import com.example.data.remote.PayoutMethod
import com.example.data.remote.TaskCategory
import com.example.data.remote.TaskItem
import com.example.data.remote.UserProfile
import com.example.data.remote.WithdrawalRecord
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val firebaseManager: FirebaseManager,
    private val rewardRepository: RewardRepository,
    private val currentUserId: String,
    private val isLocalMode: Boolean = false
) : ViewModel() {

    val balance: StateFlow<UserBalanceEntity> = rewardRepository.balance
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = UserBalanceEntity()
        )

    val appConfig: StateFlow<AppConfig> =
        (if (isLocalMode) flowOf(AppConfig()) else firebaseManager.observeAppConfig())
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = AppConfig()
            )

    val userProfile: StateFlow<UserProfile?> =
        (if (isLocalMode) {
            flowOf(
                UserProfile(
                    id = currentUserId,
                    uid = currentUserId,
                    displayName = "Guest Explorer",
                    email = "Offline Local Mode"
                )
            )
        } else {
            firebaseManager.observeUserProfile(currentUserId).onEach { profile ->
                if (profile != null) {
                    rewardRepository.syncFromRemoteProfile(profile)
                }
            }
        }).stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = null
        )

    val tasks: StateFlow<List<TaskItem>> =
        (if (isLocalMode) flowOf(emptyList()) else firebaseManager.observeTasks())
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = emptyList()
            )

    val taskCategories: StateFlow<List<TaskCategory>> =
        (if (isLocalMode) flowOf(emptyList()) else firebaseManager.observeTaskCategories())
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = emptyList()
            )

    val payoutMethods: StateFlow<List<PayoutMethod>> =
        (if (isLocalMode) flowOf(BuiltInPayoutMethods.defaults) else firebaseManager.observePayoutMethods())
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = BuiltInPayoutMethods.defaults
            )

    val transactions: StateFlow<List<TransactionEntity>> = rewardRepository.transactions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val withdrawals: StateFlow<List<WithdrawalRecord>> =
        (if (isLocalMode) flowOf(emptyList()) else firebaseManager.observeWithdrawals(currentUserId))
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = emptyList()
            )

    val completedTaskIds: StateFlow<Set<String>> = rewardRepository.completedTaskIds
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptySet()
        )

    private val _isLeaderboardLoading = MutableStateFlow(!isLocalMode)
    val isLeaderboardLoading: StateFlow<Boolean> = _isLeaderboardLoading.asStateFlow()

    val leaderboard: StateFlow<List<LeaderboardEntry>> =
        (if (isLocalMode) {
            flowOf(
                listOf(
                    LeaderboardEntry(
                        id = currentUserId,
                        uid = currentUserId,
                        displayName = "Guest Explorer",
                        dailyCoins = 50,
                        weeklyCoins = 50
                    )
                )
            )
        } else {
            firebaseManager.observeLeaderboard().onEach { _isLeaderboardLoading.value = false }
        }).stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    init {
        if (!isLocalMode) {
            viewModelScope.launch {
                firebaseManager.currentUser?.let { user ->
                    val profile = firebaseManager.ensureUserDocument(user, AppConfig())
                    rewardRepository.syncFromRemoteProfile(profile)
                }
            }
        }
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }

    fun completeTask(task: TaskItem) {
        if (userProfile.value?.isBlocked == true) {
            _actionMessage.value = "Account Blocked by Admin. Reward claims are restricted."
            return
        }
        viewModelScope.launch {
            val result = rewardRepository.completeTaskAndClaimCoins(task)
            _actionMessage.value = if (result.isSuccess) {
                "+${task.rewardCoins} Coins added to your balance!"
            } else {
                result.exceptionOrNull()?.message ?: "Could not complete task."
            }
        }
    }

    fun requestWithdrawal(
        method: PayoutMethod,
        accountDetail: String,
        coinsToDeduct: Int,
        cashAmount: Double,
        onSuccess: () -> Unit
    ) {
        if (userProfile.value?.isBlocked == true) {
            _actionMessage.value = "Account Blocked by Admin. Withdrawals are restricted."
            return
        }
        viewModelScope.launch {
            val result = rewardRepository.requestWithdrawal(
                method = method,
                accountDetail = accountDetail,
                coinsToDeduct = coinsToDeduct,
                cashAmount = cashAmount
            )
            if (result.isSuccess) {
                _actionMessage.value = "Withdrawal request submitted! ₹${cashAmount.toInt()} payout is pending."
                onSuccess()
            } else {
                _actionMessage.value = result.exceptionOrNull()?.message ?: "Withdrawal failed."
            }
        }
    }
}
