package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.GemQuestApplication
import com.example.ui.components.QuestBottomBar
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageFinderScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.PayoutDetailScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SuperOfferDetailsScreen
import com.example.ui.screens.SuperOfferHubScreen
import com.example.ui.screens.TaskHistoryScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.UsagePermissionScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.MainBackground
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.ImageFinderViewModel
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.SuperOfferViewModel
import com.google.firebase.auth.FirebaseUser

object QuestRoutes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val TASKS = "tasks"
    const val LEADERBOARD = "leaderboard"
    const val WALLET = "wallet"
    const val SUPER_OFFER_HUB = "super_offer_hub"
    const val SUPER_OFFER_DETAILS = "super_offer_details"
    const val IMAGE_FINDER = "image_finder"
    const val PROFILE = "profile"
    const val TASK_HISTORY = "task_history"
    const val USAGE_PERMISSION = "usage_permission"
    const val PAYOUT_DETAIL = "payout_detail/{method}"

    fun payoutDetail(method: String): String = "payout_detail/$method"
}

@Composable
fun QuestAppRoot() {
    val authViewModel: AuthViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as GemQuestApplication
                AuthViewModel(app.firebaseManager, app.rewardRepository)
            }
        }
    )

    val currentUser by authViewModel.currentUser.collectAsStateWithLifecycle()
    val isLocalExploreMode by authViewModel.isLocalExploreMode.collectAsStateWithLifecycle()
    val user = currentUser

    if (user == null && !isLocalExploreMode) {
        LoginScreen(authViewModel = authViewModel)
    } else {
        val sessionUid = user?.uid ?: "local_explorer"
        val isLocalMode = (user == null)
        key(sessionUid) {
            AuthenticatedQuestShell(
                user = user,
                sessionUid = sessionUid,
                isLocalMode = isLocalMode,
                authViewModel = authViewModel
            )
        }
    }
}

@Composable
private fun AuthenticatedQuestShell(
    user: FirebaseUser?,
    sessionUid: String,
    isLocalMode: Boolean,
    authViewModel: AuthViewModel
) {
    val context = LocalContext.current
    val app = context.applicationContext as GemQuestApplication
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val mainViewModel: MainViewModel = viewModel(
        key = "main_$sessionUid",
        factory = viewModelFactory {
            initializer {
                val application = checkNotNull(this[APPLICATION_KEY]) as GemQuestApplication
                MainViewModel(
                    firebaseManager = application.firebaseManager,
                    rewardRepository = application.rewardRepository,
                    currentUserId = sessionUid,
                    isLocalMode = isLocalMode
                )
            }
        }
    )

    val superOfferViewModel: SuperOfferViewModel = viewModel(
        key = "super_$sessionUid",
        factory = viewModelFactory {
            initializer {
                val application = checkNotNull(this[APPLICATION_KEY]) as GemQuestApplication
                SuperOfferViewModel(
                    rewardRepository = application.rewardRepository,
                    firebaseManager = application.firebaseManager,
                    installationRepository = application.installationRepository,
                    usageTrackingRepository = application.usageTrackingRepository,
                    isLocalMode = isLocalMode
                )
            }
        }
    )

    val showBottomBar = currentRoute in setOf(
        QuestRoutes.HOME,
        QuestRoutes.TASKS,
        QuestRoutes.LEADERBOARD,
        QuestRoutes.WALLET
    )

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MainBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBottomBar) {
                QuestBottomBar(
                    currentRoute = currentRoute,
                    onNavigate = { route -> navigateToTab(route) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = QuestRoutes.HOME
            ) {
                composable(QuestRoutes.HOME) {
                    HomeScreen(
                        mainViewModel = mainViewModel,
                        adManager = app.unityRewardedAdManager,
                        firebaseUser = user,
                        onOpenWallet = { navigateToTab(QuestRoutes.WALLET) },
                        onOpenSuperOffer = { navController.navigate(QuestRoutes.SUPER_OFFER_HUB) },
                        onOpenImageFinder = { navController.navigate(QuestRoutes.IMAGE_FINDER) },
                        onOpenTasks = { navigateToTab(QuestRoutes.TASKS) },
                        onOpenProfile = { navController.navigate(QuestRoutes.PROFILE) },
                        onOpenHistory = { navController.navigate(QuestRoutes.TASK_HISTORY) },
                        onLogout = { authViewModel.signOut(context) }
                    )
                }

                composable(QuestRoutes.TASKS) {
                    TasksScreen(
                        mainViewModel = mainViewModel,
                        onOpenSuperOffer = { navController.navigate(QuestRoutes.SUPER_OFFER_HUB) }
                    )
                }

                composable(QuestRoutes.LEADERBOARD) {
                    LeaderboardScreen(
                        mainViewModel = mainViewModel,
                        currentUserId = sessionUid
                    )
                }

                composable(QuestRoutes.WALLET) {
                    WalletScreen(
                        mainViewModel = mainViewModel,
                        onSelectMethod = { methodId ->
                            navController.navigate(QuestRoutes.payoutDetail(methodId))
                        }
                    )
                }

                composable(QuestRoutes.SUPER_OFFER_HUB) {
                    SuperOfferHubScreen(
                        viewModel = superOfferViewModel,
                        onBack = { navController.popBackStack() },
                        onNavigateToDetails = { navController.navigate(QuestRoutes.SUPER_OFFER_DETAILS) },
                        onNavigateToUsagePermission = { navController.navigate(QuestRoutes.USAGE_PERMISSION) }
                    )
                }

                composable(QuestRoutes.USAGE_PERMISSION) {
                    UsagePermissionScreen(
                        viewModel = superOfferViewModel,
                        onBack = { navController.popBackStack() },
                        onPermissionGranted = {
                            navController.popBackStack()
                        }
                    )
                }

                composable(QuestRoutes.SUPER_OFFER_DETAILS) {
                    SuperOfferDetailsScreen(
                        viewModel = superOfferViewModel,
                        adManager = app.unityRewardedAdManager,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(QuestRoutes.IMAGE_FINDER) {
                    val imageFinderViewModel: ImageFinderViewModel = viewModel(
                        factory = viewModelFactory {
                            initializer {
                                val application = checkNotNull(this[APPLICATION_KEY]) as GemQuestApplication
                                ImageFinderViewModel(application.rewardRepository)
                            }
                        }
                    )
                    val config by mainViewModel.appConfig.collectAsStateWithLifecycle()
                    ImageFinderScreen(
                        viewModel = imageFinderViewModel,
                        adManager = app.unityRewardedAdManager,
                        gemRewardPerRound = config.gemRewardPerRound,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(QuestRoutes.PROFILE) {
                    ProfileScreen(
                        mainViewModel = mainViewModel,
                        adManager = app.unityRewardedAdManager,
                        firebaseUser = user,
                        onBack = { navController.popBackStack() },
                        onOpenHistory = { navController.navigate(QuestRoutes.TASK_HISTORY) },
                        onLogoutOrSwitch = { authViewModel.signOut(context) }
                    )
                }

                composable(QuestRoutes.TASK_HISTORY) {
                    TaskHistoryScreen(
                        mainViewModel = mainViewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = QuestRoutes.PAYOUT_DETAIL,
                    arguments = listOf(navArgument("method") { type = NavType.StringType })
                ) { entry ->
                    val method = entry.arguments?.getString("method") ?: "PAYTM"
                    PayoutDetailScreen(
                        methodId = method,
                        mainViewModel = mainViewModel,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
